require("dotenv").config();
const TelegramBot = require("node-telegram-bot-api");
const axios = require("axios");
const ytdl = require("@distube/ytdl-core");
const path = require("path");
const fs = require("fs");
const os = require("os");
const { pipeline } = require("stream/promises");
const FormData = require("form-data");

let ytScraper = null;
try {
  ytScraper = require("@vreden/youtube_scraper");
} catch (e) {
  console.error("⚠️ @vreden/youtube_scraper missing. Run: npm install");
}

const BOT_TOKEN = process.env.BOT_TOKEN;
const FORCE_JOIN_CHANNEL = (process.env.FORCE_JOIN_CHANNEL || "").trim();
const SIM_API_URL = process.env.SIM_API_URL || "https://sim-info-api.wasif-ali.workers.dev/?search={number}";
const AIO_API = process.env.AIO_API || "https://prexzyapis.com/download/aio";
const YT_AUDIO_API = process.env.YT_AUDIO_API || "";
const OWNER_URL = process.env.OWNER_URL || "https://t.me/bilal_babar_982";
const OWNER_ID = process.env.OWNER_ID || "7615067790";
const OWNER_USERNAME = process.env.OWNER_USERNAME || "bilal_babar_982";

// ===== Prince Tech API base (all-in-one provider) =====
const PRINCE_API = "https://api.princetechn.com/api";
const PRINCE_KEY = process.env.PRINCE_API_KEY || "prince";
function princeUrl(pathAndQuery) {
  const sep = pathAndQuery.includes("?") ? "&" : "?";
  return `${PRINCE_API}${pathAndQuery}${sep}apikey=${encodeURIComponent(PRINCE_KEY)}`;
}

if (!BOT_TOKEN) {
  console.error("❌ BOT_TOKEN missing in .env");
  process.exit(1);
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

const BRAND = "𝗕𝗜𝗟𝗔𝗟 𝐊𝐈𝐍𝐆";
const FOOTER = `\n\n━━━━━━━━━━━━━━━\n⚡ Powered by <b>${BRAND}</b>`;
const MENU_PHOTO = path.join(__dirname, "assets", "menu.jpg");

// Per-user pending order state (in-memory)
const pendingOrder = new Map(); // userId -> { plan, priceText }

process.on("unhandledRejection", (err) => {
  console.error("Unhandled promise rejection:", err?.message || err);
});

process.on("uncaughtException", (err) => {
  console.error("Uncaught exception:", err?.message || err);
});

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

async function safeSendMessage(chatId, text, options = {}) {
  const opts = { parse_mode: "HTML", ...options };
  try {
    return await bot.sendMessage(chatId, text, opts);
  } catch (e) {
    console.error("sendMessage err:", e.message);
    return bot.sendMessage(chatId, String(text).replace(/<[^>]*>/g, ""), {
      ...options,
      parse_mode: undefined,
    });
  }
}

function isHttpUrl(value) {
  return typeof value === "string" && /^https?:\/\//i.test(value);
}

async function downloadToTempFile(url, ext = "mp3") {
  const safeExt = String(ext || "mp3").replace(/[^a-z0-9]/gi, "") || "mp3";
  const filePath = path.join(os.tmpdir(), `bilal-king-${Date.now()}-${Math.random().toString(16).slice(2)}.${safeExt}`);
  const response = await axios.get(url, {
    responseType: "stream",
    timeout: 120000,
    maxRedirects: 5,
    headers: {
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36",
      accept: "audio/mpeg,audio/*,*/*",
    },
  });
  await pipeline(response.data, fs.createWriteStream(filePath));
  return filePath;
}

async function safeEditMessageText(text, options = {}) {
  const opts = { parse_mode: "HTML", ...options };
  try {
    return await bot.editMessageText(text, opts);
  } catch (e) {
    console.error("editMessageText err:", e.message);
    return bot
      .editMessageText(String(text).replace(/<[^>]*>/g, ""), {
        ...options,
        parse_mode: undefined,
      })
      .catch(() => {});
  }
}

async function safeSendPhoto(chatId, photo, options = {}) {
  const opts = { parse_mode: "HTML", ...options };
  try {
    return await bot.sendPhoto(chatId, photo, opts);
  } catch (e) {
    console.error("sendPhoto err:", e.message);
    if (options.caption) {
      return safeSendMessage(chatId, options.caption, { reply_markup: options.reply_markup });
    }
  }
}

async function safeSendAudio(chatId, audio, options = {}) {
  const opts = { parse_mode: "HTML", ...options };
  try {
    return await bot.sendAudio(chatId, audio, opts);
  } catch (e) {
    console.error("sendAudio err:", e.message);
    if (isHttpUrl(audio)) {
      let filePath = "";
      try {
        filePath = await downloadToTempFile(audio, "mp3");
        return await bot.sendAudio(chatId, filePath, opts);
      } catch (fileError) {
        console.error("sendAudio local-file fallback err:", fileError.message);
      } finally {
        if (filePath) fs.unlink(filePath, () => {});
      }
    }
    return safeSendMessage(chatId, `⚠️ Audio send fail: ${esc(e.message)}${FOOTER}`);
  }
}

async function safeSendVideo(chatId, video, options = {}) {
  const opts = { parse_mode: "HTML", ...options };
  try {
    return await bot.sendVideo(chatId, video, opts);
  } catch (e) {
    console.error("sendVideo err:", e.message);
    return safeSendMessage(chatId, `⚠️ Video send fail: ${esc(e.message)}${FOOTER}`);
  }
}

function stylizeButton(icon, text, end = "") {
  return `${icon}  ┃ ${text} ┃  ${end || icon}`;
}

function officialButton(icon, text, end = "") {
  return `${icon} ${text} ${end || icon}`;
}

function dividerButton(icon, text) {
  return `${icon}━━━━━━━━  ${text}  ━━━━━━━━${icon}`;
}

function backToMenuKeyboard() {
  return { inline_keyboard: [[{ text: officialButton("🏠", "Back to Menu", "🏠"), callback_data: "main_menu" }]] };
}

function cleanTitle(value, fallback = "Downloaded Media") {
  return String(value || fallback).replace(/[\r\n]+/g, " ").slice(0, 90);
}

// ================= BAN SYSTEM =================
const BANNED_FILE = path.join(__dirname, "banned.json");
let bannedUsers = new Set();

function loadBannedUsers() {
  try {
    if (fs.existsSync(BANNED_FILE)) {
      bannedUsers = new Set(JSON.parse(fs.readFileSync(BANNED_FILE, "utf8")));
    }
  } catch (e) {
    console.error("banned load err:", e.message);
  }
}
function saveBannedUsers() {
  try {
    fs.writeFileSync(BANNED_FILE, JSON.stringify([...bannedUsers], null, 2));
  } catch (e) {
    console.error("banned save err:", e.message);
  }
}
loadBannedUsers();

// ================= USER TRACKING (for /stats, /broadcast) =================
const USERS_FILE = path.join(__dirname, "users.json");
let knownUsers = new Map(); // userId -> { username, firstName, joinedAt }

function loadKnownUsers() {
  try {
    if (fs.existsSync(USERS_FILE)) {
      const raw = JSON.parse(fs.readFileSync(USERS_FILE, "utf8"));
      knownUsers = new Map(Object.entries(raw));
    }
  } catch (e) {
    console.error("users load err:", e.message);
  }
}
function saveKnownUsers() {
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(Object.fromEntries(knownUsers), null, 2));
  } catch (e) {
    console.error("users save err:", e.message);
  }
}
function registerUser(msg) {
  const id = String(msg.from.id);
  if (!knownUsers.has(id)) {
    knownUsers.set(id, {
      username: msg.from.username || "",
      firstName: msg.from.first_name || "",
      joinedAt: new Date().toISOString(),
    });
    saveKnownUsers();
  }
}
loadKnownUsers();


async function isJoined(userId) {
  if (bannedUsers.has(String(userId))) return false; // banned users treated as blocked everywhere
  if (!FORCE_JOIN_CHANNEL) return true;
  try {
    const ch = FORCE_JOIN_CHANNEL.startsWith("@") ? FORCE_JOIN_CHANNEL : "@" + FORCE_JOIN_CHANNEL;
    const m = await bot.getChatMember(ch, userId);
    return ["member", "administrator", "creator"].includes(m.status);
  } catch (e) {
    console.error("Force join check failed:", e.message);
    return false;
  }
}

async function sendJoinPrompt(chatId) {
  if (bannedUsers.has(String(chatId))) {
    return safeSendMessage(
      chatId,
      `🚫 <b>Aapko is bot se block kar diya gaya hai.</b>\n\nAgar ye galti hai to owner se contact karo:\n👉 https://t.me/${esc(OWNER_USERNAME)}${FOOTER}`
    );
  }
  const ch = FORCE_JOIN_CHANNEL.replace("@", "");
  const text =
    `🔒 <b>Access Locked</b>\n\n` +
    `Bot use karne ke liye pehle hamara channel join karo, phir ✅ <b>I Joined</b> dabao.` +
    FOOTER;
  await safeSendMessage(chatId, text, {
    reply_markup: {
      inline_keyboard: [
        [{ text: stylizeButton("🟣", "📢 JOIN CHANNEL", "🟣"), url: `https://t.me/${ch}` }],
        [{ text: stylizeButton("🟢", "✅ I JOINED", "🟢"), callback_data: "check_join" }],
      ],
    },
  });
}

// ================= MAIN MENU =================
function mainMenuKeyboard() {
  return {
    inline_keyboard: [
      [
        { text: stylizeButton("👑", "OWNER", "👑"), url: OWNER_URL },
        { text: stylizeButton("📢", "CHANNEL", "📢"), url: `https://t.me/${FORCE_JOIN_CHANNEL.replace("@", "") || "telegram"}` },
      ],
      [{ text: officialButton("🛒", "💎 AUTO ORDER / BUY NOW 💎", "🛒"), callback_data: "help_order" }],
      [{ text: dividerButton("🟪", "▶️ NEXT — ALL COMMANDS ◀️"), callback_data: "cat_0" }],
    ],
  };
}

function menuCaption(name) {
  return (
    `◤━━━━━━━━━━━━━━━━━━◥\n` +
    `   ⚡ <b>${BRAND}  ⋆  OFFICIAL</b> ⚡\n` +
    `◣━━━━━━━━━━━━━━━━━━◢\n\n` +
    `💫 <b>Assalam-o-Alaikum</b> ${esc(name)} 💫\n\n` +
    `╭─❒ 「 🌟 <b>${BRAND} ─ MAIN MENU</b> 」\n` +
    `│\n` +
    `│ 🚀 Welcome to ${BRAND} — Pakistan ka fastest\n` +
    `│    all-in-one Telegram bot.\n` +
    `│\n` +
    `│ 📥 Downloader  ·  🤖 AI  ·  🛠️ Utilities\n` +
    `│ 💻 Developer   ·  🛒 Order  · 👑 Owner\n` +
    `│\n` +
    `│ 👉 Neeche <b>NEXT</b> button dabao,\n` +
    `│    har category ka full menu khulega\n` +
    `│    (Next / Back / Home).\n` +
    `╰━━━━━━━━━━━━━━━━━⦿` +
    FOOTER
  );
}

async function sendPhotoMenu(chatId, caption, keyboard) {
  const opts = { caption, parse_mode: "HTML", reply_markup: keyboard };
  try {
    if (fs.existsSync(MENU_PHOTO)) {
      const stream = fs.createReadStream(MENU_PHOTO);
      return await bot.sendPhoto(chatId, stream, opts, { filename: "menu.jpg", contentType: "image/jpeg" });
    }
  } catch (e) {
    console.error("photo err:", e.message);
  }
  return safeSendMessage(chatId, caption, { reply_markup: keyboard });
}

// ================= CATEGORY PAGES (Downloader → AI → Utilities → Developer → Order → Owner) =================
const CATEGORIES = [
  {
    icon: "📥",
    title: "DOWNLOADER",
    lines: [
      "🔴 /tt <url>            ─ TikTok",
      "🔵 /fb <url>            ─ Facebook",
      "🟣 /ig <url>            ─ Instagram",
      "🎬 /video <name/url>    ─ YouTube MP4",
      "🎵 /song  <name/url>    ─ YouTube MP3",
      "▶️ /play  <name/url>    ─ Play MP3",
      "📦 /mediafire <url>     ─ Mediafire",
      "🔞 /xsearch <text>      ─ 18+ Search (15-20)",
      "🔞 /xnxx <url>          ─ 18+ Download",
    ],
  },
  {
    icon: "🤖",
    title: "AI TOOLS",
    lines: [
      "🧠 /ai <q>              ─ Urdu AI Chat",
      "✨ /bilalg <q>          ─ Gemini AI",
      "💬 /bilalgp <q>         ─ ChatGPT",
      "🗣️ /text <text>         ─ Text → Voice (TTS)",
      "🌐 /tr <lang> <text>    ─ Translator",
    ],
  },
  {
    icon: "🛠️",
    title: "UTILITIES",
    lines: [
      "📱 /sim <03xxx>         ─ SIM Info",
      "📧 /temp                ─ Fake Temp Mail",
      "🎨 /bilal-logo <text>   ─ 3D Silver Logo",
      "🔗 /url                 ─ File → Direct Link",
      "🆔 /id                  ─ Your Telegram ID",
    ],
  },
  {
    icon: "💻",
    title: "DEVELOPER",
    lines: [
      "🔍 /ckerror             ─ JS Error Check",
      "🛠️ /fixerror            ─ JS Auto Fix",
      "🔐 /encrypt             ─ JS / ZIP Obfuscate",
      "🪪 /pusttoken           ─ Multi-Bot Tokens",
    ],
  },
  {
    icon: "🛒",
    title: "ORDER",
    lines: [
      "💎 /order               ─ Buy Bot / Script",
      "🏠 /menu                ─ Main Menu",
      "📩 /start               ─ Restart Bot",
    ],
  },
  {
    icon: "👑",
    title: "OWNER ONLY",
    lines: [
      "📊 /stats               ─ Bot Stats",
      "📣 /broadcast <msg>     ─ Broadcast",
      "🚫 /ban <id>            ─ Ban User",
      "✅ /unban <id>          ─ Unban User",
      "🕒 /autopost            ─ Auto Channel Post",
    ],
  },
];

function categoryCaption(i) {
  const c = CATEGORIES[i];
  const total = CATEGORIES.length;
  let s =
    `◤━━━━━━━━━━━━━━━━━━◥\n` +
    `  ${c.icon} <b>${esc(c.title)}</b>  ─ MENU ${i + 1}/${total}\n` +
    `◣━━━━━━━━━━━━━━━━━━◢\n\n` +
    `╭─❒ 「 <b>${BRAND}</b> 」\n│\n`;
  c.lines.forEach((ln) => (s += `│ ${esc(ln)}\n`));
  s +=
    `│\n` +
    `╰━━━━━━━━━━━━━━━━━⦿\n\n` +
    `👉 Neeche <b>NEXT</b> se agli category kholo,\n` +
    `   ya seedha koi bhi command send karo.` +
    FOOTER;
  return s;
}

function categoryKeyboard(i) {
  const total = CATEGORIES.length;
  const prev = (i - 1 + total) % total;
  const next = (i + 1) % total;
  return {
    inline_keyboard: [
      [
        { text: officialButton("⬅️", "BACK", "🔙"), callback_data: `cat_${prev}` },
        { text: officialButton("➡️", "NEXT", "⏭️"), callback_data: `cat_${next}` },
      ],
      [{ text: dividerButton("🏠", "MAIN MENU"), callback_data: "main_menu" }],
    ],
  };
}

async function sendCategory(chatId, i) {
  return sendPhotoMenu(chatId, categoryCaption(i), categoryKeyboard(i));
}

async function sendMainMenu(chatId, name) {
  return sendPhotoMenu(chatId, menuCaption(name), mainMenuKeyboard());
}

// ================= TUTORIAL PAGES =================
const TUTORIALS = [
  {
    key: "tt",
    title: "🔴 TikTok Downloader",
    cmd: "/tt",
    example: "/tt https://vm.tiktok.com/xxxxx",
    desc: "TikTok video ka link bhejo — bot HD video download kar ke bhejega (bina watermark).",
  },
  {
    key: "fb",
    title: "🔵 Facebook Downloader",
    cmd: "/fb",
    example: "/fb https://facebook.com/xxxx/videos/xxxx",
    desc: "Facebook video / reel ka public link bhejo — bot MP4 download kar dega.",
  },
  {
    key: "ig",
    title: "🟣 Instagram Downloader",
    cmd: "/ig",
    example: "/ig https://instagram.com/reel/xxxx",
    desc: "Instagram Reel / Post / IGTV ka link bhejo — bot media file bhej dega.",
  },
  {
    key: "video",
    title: "🔴 YouTube Video (MP4)",
    cmd: "/video",
    example: "/video https://youtu.be/xxxxxxx",
    desc: "YouTube video ka link bhejo — bot MP4 format me download kar ke bhejega.",
  },
  {
    key: "song",
    title: "🟡 YouTube Song (MP3)",
    cmd: "/song",
    example: "/song Dil Dil Ye Dil  ya  /song https://youtu.be/xxxxxxx",
    desc: "YouTube ka link ya sirf gaane ka naam bhejo — bot khud dhoond kar audio MP3 nikal ke bhejega.",
  },
  {
    key: "sim",
    title: "🟢 Pakistan SIM Info",
    cmd: "/sim",
    example: "/sim 03XXXXXXXXX",
    desc: "Pakistani number bhejo — bot Name, CNIC, Address details bhej dega.",
  },
  {
    key: "tr",
    title: "🌐 Translator",
    cmd: "/tr",
    example: "/tr ur Hello my friend",
    desc:
      "Kisi bhi zuban me translate karo.\nFormat: /tr <lang> <text>\n" +
      "Lang codes: ur Urdu, en English, hi Hindi, ar Arabic, es Spanish, fr French, zh Chinese, ru Russian, tr Turkish, de German, etc.",
  },
  {
    key: "order",
    title: "🛒 Auto Order",
    cmd: "/order",
    example: "/order",
    desc:
      "Bot / Script / Hosting order karna hai? `/order` dabao — plans + payment method dikh jayenge. Payment ke baad SS bhejo, owner ko forward ho jayega.",
  },
  {
    key: "url",
    title: "🔗 File → Direct URL",
    cmd: "/url",
    example: "Photo/video/audio bhejo caption me /url likh kar",
    desc: "Koi bhi photo, video ya audio bhejo (caption me `/url` likh kar), ya kisi media par reply karke `/url` bhejo — bot uska direct download link bana ke dega.",
  },
];

// Extra command guides (Prince Tech APIs + new features)
TUTORIALS.push(
  {
    key: "temp",
    title: "📧 Temp Mail Inbox",
    cmd: "/temp",
    example: "/temp abcxyz@1secmail.com",
    desc: "Temporary email inbox check karo — sari mails is command se aa jayengi.",
  },
  {
    key: "bilallogo",
    title: "🎨 BILAL Logo Maker",
    cmd: "/bilal-logo",
    example: "/bilal-logo Prince Tech",
    desc: "Glossy silver 3D style logo bana kar bhej dega — bas apna naam / text likho.",
  },
  {
    key: "mediafire",
    title: "📥 Mediafire Downloader",
    cmd: "/mediafire",
    example: "/mediafire https://www.mediafire.com/file/xxxx",
    desc: "Mediafire ka koi bhi file link bhejo — bot direct download link + file bhej dega.",
  },
  {
    key: "text2speech",
    title: "🎤 Audio → Text (Transcribe)",
    cmd: "/text",
    example: "/text https://example.com/song.mp3",
    desc: "Audio ya voice file ka URL do — bot us audio ka text (transcript) bhej dega.",
  },
  {
    key: "bilalg",
    title: "🤖 BILAL Gemini AI",
    cmd: "/bilalg",
    example: "/bilalg Aaj ka mausam kaisa hai?",
    desc: "Google Gemini AI se sawal poocho — bot fast reply karega.",
  },
  {
    key: "bilalgp",
    title: "💬 BILAL ChatGPT",
    cmd: "/bilalgp",
    example: "/bilalgp Node.js kya hai?",
    desc: "ChatGPT se koi bhi sawal poocho — bot detailed reply karega.",
  },
  {
    key: "xnxx",
    title: "🔞 XNXX Downloader (18+)",
    cmd: "/xnxx",
    example: "/xnxx https://www.xnxx.com/video-xxxx/xxxx",
    desc: "XNXX ka link bhejo — bot MP4 download kar ke bhej dega. Sirf 18+ users ke liye.",
  },
  {
    key: "play",
    title: "▶️ Play (YouTube MP3)",
    cmd: "/play",
    example: "/play Atif Aslam Tere Liye",
    desc: "Song ka naam ya YouTube link do — bot Prince Tech API se MP3 bhej dega.",
  },
  {
    key: "encrypt",
    title: "🔐 Script Encrypt (Obfuscate)",
    cmd: "/encrypt",
    example: "index.js file bhejo caption me /encrypt likh kar (ya reply karke)",
    desc:
      "Single JS file (jaise index.js) ya poori project ZIP bhejo — bot sab .js files obfuscate karega. " +
      "⚠️ config.js / package.json / package-lock.json / .env aise sensitive files SKIP hongi taake token ya settings safe rahen.",
  }
);

function tutorialCaption(i) {
  const t = TUTORIALS[i];
  return (
    `📖 <b>Guide ${i + 1}/${TUTORIALS.length}</b>\n\n` +
    `<b>${esc(t.title)}</b>\n\n` +
    `📝 ${esc(t.desc)}\n\n` +
    `⌨️ <b>Command:</b> <code>${esc(t.cmd)}</code>\n` +
    `💡 <b>Example:</b> <code>${esc(t.example)}</code>` +
    FOOTER
  );
}

function tutorialKeyboard(i) {
  const prev = i === 0 ? TUTORIALS.length - 1 : i - 1;
  const next = (i + 1) % TUTORIALS.length;
  return {
    inline_keyboard: [
      [{ text: officialButton("🚀", `USE ${TUTORIALS[i].cmd.toUpperCase()}`, "🚀"), callback_data: `use_${TUTORIALS[i].key}` }],
      [
        { text: officialButton("⬅️", "BACK", "🔙"), callback_data: `tut_${prev}` },
        { text: officialButton("➡️", "NEXT", "⏭️"), callback_data: `tut_${next}` },
      ],
      [{ text: dividerButton("🏠", "MAIN MENU"), callback_data: "main_menu" }],
    ],
  };
}

async function sendTutorial(chatId, i) {
  return sendPhotoMenu(chatId, tutorialCaption(i), tutorialKeyboard(i));
}

// ================= ORDER MENU =================
const PLANS = [
  { id: "vip1m", title: "🤖 Bug Bot VIP — 1 Month", price: "1000 PKR" },
  { id: "vip_life", title: "💎 Bug Bot Lifetime Premium", price: "5000 PKR" },
  { id: "host", title: "🖥️ Bot Hosting Panel — Unlimited RAM", price: "400 PKR / month" },
  { id: "func", title: "⚙️ Bug Function / Function Adding", price: "On demand" },
  { id: "scripts", title: "📜 All Scripts Available", price: "On demand" },
];

function orderMenuCaption() {
  let s = `🛒 <b>AUTO ORDER MENU</b>\n\n`;
  PLANS.forEach((p) => (s += `┣ ${esc(p.title)}\n┃   💰 <b>${esc(p.price)}</b>\n`));
  s +=
    `\n💳 <b>Payment Methods:</b>\n` +
    `┣ 🟠 <b>JazzCash:</b> <code>03090211619</code>\n` +
    `┃   Name: <b>Babar Ali</b>\n` +
    `┣ 🟡 <b>Binance:</b> <code>1224870383</code>\n` +
    `┃   Name: <b>Bilal_king982</b>\n\n` +
    `👇 Neeche plan select karo, payment karo, phir <b>SS bhejo</b> — owner ko forward ho jayega.` +
    FOOTER;
  return s;
}

function orderKeyboard() {
  const icons = ["🟣", "🔴", "🟢", "🔵", "🟡"];
  const rows = PLANS.map((p, index) => [
    { text: officialButton(icons[index] || "⚡", `${p.title} ┃ ${p.price}`, icons[index] || "⚡"), callback_data: `plan_${p.id}` },
  ]);
  rows.push([
    { text: officialButton("🟠", "JazzCash", "🟠"), callback_data: "pay_jc" },
    { text: officialButton("🟡", "Binance", "🟡"), callback_data: "pay_bn" },
  ]);
  rows.push([{ text: dividerButton("📩", "CONTACT OWNER"), url: `https://t.me/${OWNER_USERNAME}` }]);
  rows.push([{ text: dividerButton("🏠", "MAIN MENU"), callback_data: "main_menu" }]);
  return { inline_keyboard: rows };
}

async function sendOrderMenu(chatId) {
  return sendPhotoMenu(chatId, orderMenuCaption(), orderKeyboard());
}

// ================= /start =================
bot.onText(/^\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const name = msg.from.first_name || "User";
  registerUser(msg);
  if (!(await isJoined(userId))) return sendJoinPrompt(chatId);
  await sendMainMenu(chatId, name);
});

bot.onText(/^\/menu/, async (msg) => {
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(msg.chat.id);
  sendMainMenu(msg.chat.id, msg.from.first_name || "User");
});

bot.onText(/^\/order/, async (msg) => {
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(msg.chat.id);
  sendOrderMenu(msg.chat.id);
});

// ================= CALLBACKS =================
bot.on("callback_query", async (q) => {
  const chatId = q.message.chat.id;
  const userId = q.from.id;
  const name = q.from.first_name || "User";
  const data = q.data;

  try {
    if (data === "check_join") {
      if (await isJoined(userId)) {
        await bot.answerCallbackQuery(q.id, { text: "✅ Verified!" });
        await bot.deleteMessage(chatId, q.message.message_id).catch(() => {});
        return sendMainMenu(chatId, name);
      }
      return bot.answerCallbackQuery(q.id, { text: "❌ Abhi tak join nahi kiya!", show_alert: true });
    }

    if (!(await isJoined(userId))) {
      await bot.answerCallbackQuery(q.id);
      return sendJoinPrompt(chatId);
    }

    if (data === "main_menu") {
      await bot.answerCallbackQuery(q.id);
      await bot.deleteMessage(chatId, q.message.message_id).catch(() => {});
      return sendMainMenu(chatId, name);
    }

    if (data === "profile_hint") {
      await bot.answerCallbackQuery(q.id, { text: "Bot DP change karne ke liye BotFather me /setuserpic use karo.", show_alert: true });
      return;
    }

    if (data.startsWith("tut_")) {
      const i = parseInt(data.slice(4), 10) || 0;
      await bot.answerCallbackQuery(q.id);
      await bot.deleteMessage(chatId, q.message.message_id).catch(() => {});
      return sendTutorial(chatId, i);
    }

    if (data.startsWith("cat_")) {
      const i = parseInt(data.slice(4), 10) || 0;
      const safe = ((i % CATEGORIES.length) + CATEGORIES.length) % CATEGORIES.length;
      await bot.answerCallbackQuery(q.id);
      await bot.deleteMessage(chatId, q.message.message_id).catch(() => {});
      return sendCategory(chatId, safe);
    }

    if (data.startsWith("use_")) {
      const key = data.slice(4);
      const t = TUTORIALS.find((x) => x.key === key);
      await bot.answerCallbackQuery(q.id, { text: `Send: ${t.cmd} <input>`, show_alert: true });
      return;
    }

    if (data.startsWith("help_")) {
      const key = data.slice(5);
      if (key === "order") {
        await bot.answerCallbackQuery(q.id);
        await bot.deleteMessage(chatId, q.message.message_id).catch(() => {});
        return sendOrderMenu(chatId);
      }
      const i = TUTORIALS.findIndex((x) => x.key === key);
      if (i >= 0) {
        await bot.answerCallbackQuery(q.id);
        await bot.deleteMessage(chatId, q.message.message_id).catch(() => {});
        return sendTutorial(chatId, i);
      }
    }

    // Plan selection
    if (data.startsWith("plan_")) {
      const id = data.slice(5);
      const plan = PLANS.find((p) => p.id === id);
      if (plan) {
        pendingOrder.set(userId, { plan: plan.title, priceText: plan.price });
        await bot.answerCallbackQuery(q.id, { text: "✅ Plan selected" });
        return safeSendMessage(
          chatId,
          `🧾 <b>Order Selected</b>\n\n${esc(plan.title)}\n💰 <b>${esc(plan.price)}</b>\n\n` +
            `💳 Payment options:\n` +
            `┣ 🟠 JazzCash: <code>03090211619</code> — Babar Ali\n` +
            `┗ 🟡 Binance: <code>1224870383</code> — Bilal_king982\n\n` +
            `✅ Payment ke baad <b>screenshot yahin bhejo</b> — owner ko forward ho jayega.` +
            FOOTER
        );
      }
    }

    if (data === "pay_jc") {
      await bot.answerCallbackQuery(q.id);
      return safeSendMessage(
        chatId,
        `🟠 <b>JazzCash</b>\n\n📱 Number: <code>03090211619</code>\n👤 Name: <b>Babar Ali</b>${FOOTER}`
      );
    }
    if (data === "pay_bn") {
      await bot.answerCallbackQuery(q.id);
      return safeSendMessage(
        chatId,
        `🟡 <b>Binance</b>\n\n🆔 ID: <code>1224870383</code>\n👤 Name: <b>Bilal_king982</b>${FOOTER}`
      );
    }

    await bot.answerCallbackQuery(q.id);
  } catch (e) {
    console.error("callback err:", e.message);
    bot.answerCallbackQuery(q.id, { text: "⚠️ Error" }).catch(() => {});
  }
});

// ================= DOWNLOAD HANDLER =================
function extractMedia(data) {
  if (!data) return null;
  if (typeof data === "string" && /^https?:\/\//.test(data)) return data;
  const cands = [
    data.url, data.download, data.download_url, data.video, data.audio, data.result,
    data?.data?.url, data?.data?.video, data?.data?.audio, data?.data?.download,
    Array.isArray(data?.medias) ? data.medias[0]?.url : null,
    Array.isArray(data?.data?.medias) ? data.data.medias[0]?.url : null,
  ];
  for (const c of cands) if (typeof c === "string" && /^https?:\/\//.test(c)) return c;
  return null;
}

function isYouTubeUrl(url) {
  return /(?:youtube\.com|youtu\.be)/i.test(url || "");
}

async function getCobaltAudio(url) {
  if (!YT_AUDIO_API) throw new Error("Extra audio API disabled");
  const { data } = await axios.post(
    YT_AUDIO_API,
    {
      url,
      vQuality: "720",
      isAudioOnly: true,
      aFormat: "mp3",
    },
    {
      timeout: 45000,
      headers: {
        accept: "application/json",
        "content-type": "application/json",
      },
    }
  );

  const mediaUrl = extractMedia(data) || data?.url || data?.audio;
  if (!mediaUrl) throw new Error(data?.text || data?.error || "Audio API se link nahi mila.");
  return {
    mediaUrl,
    title: data?.filename || data?.title || "YouTube Audio",
  };
}

async function getVredenAudio(url) {
  if (!ytScraper?.ytmp3) throw new Error("@vreden/youtube_scraper install nahi hai. npm install chalao.");
  const result = await ytScraper.ytmp3(url, 128);
  const mediaUrl = result?.download?.url || result?.url || extractMedia(result);
  if (!mediaUrl) throw new Error("Vreden audio link nahi mila.");
  return {
    mediaUrl,
    title: result?.metadata?.title || result?.download?.filename || "YouTube Audio",
  };
}

async function sendYouTubeAudioFallback(chatId, url, caption) {
  try {
    const vreden = await getVredenAudio(url);
    return safeSendAudio(chatId, vreden.mediaUrl, {
      caption: caption.replace("YouTube Song Downloaded", "YouTube MP3 Downloaded"),
      title: cleanTitle(vreden.title, "YouTube Audio"),
      performer: BRAND,
      reply_markup: backToMenuKeyboard(),
    });
  } catch (vredenError) {
    console.error("vreden audio err:", vredenError.message);
  }

  try {
    const cobalt = await getCobaltAudio(url);
    return safeSendAudio(chatId, cobalt.mediaUrl, {
      caption: caption.replace("YouTube Song Downloaded", "YouTube Audio Downloaded"),
      title: cleanTitle(cobalt.title, "YouTube Audio"),
      performer: BRAND,
      reply_markup: backToMenuKeyboard(),
    });
  } catch (apiError) {
    console.error("extra audio api err:", apiError.message);
  }

  try {
    const info = await ytdl.getInfo(url);
    const title = cleanTitle(info.videoDetails?.title, "YouTube Audio");
    const stream = ytdl.downloadFromInfo(info, {
      quality: "highestaudio",
      filter: "audioonly",
      highWaterMark: 1 << 25,
      requestOptions: {
        headers: {
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36",
        },
      },
    });
    return safeSendAudio(chatId, stream, {
      caption: `✅ <b>YouTube Audio Downloaded</b>\n\n🎧 ${esc(title)}${FOOTER}`,
      title,
      performer: BRAND,
      reply_markup: backToMenuKeyboard(),
    });
  } catch (directError) {
    console.error("direct ytdl audio err:", directError.message);
    throw new Error("YouTube audio download fail hua. npm install chalao aur phir restart karo; agar phir bhi fail ho to video private/age-restricted ho sakti hai.");
  }
}

async function handleDownload(msg, url, label) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const name = msg.from.first_name || "User";

  if (!(await isJoined(userId))) return sendJoinPrompt(chatId);

  if (!url || !/^https?:\/\//i.test(url)) {
    return safeSendMessage(chatId, `❌ Sahi URL bhejo.${FOOTER}`);
  }

  const status = await safeSendMessage(chatId, `⏳ <b>${esc(label)}</b> download ho raha hai...`);

  try {
    if (label.toLowerCase().includes("song") && isYouTubeUrl(url)) {
      const caption = `✅ <b>YouTube Song Downloaded</b>\n\n🎬 ${esc(label)}${FOOTER}`;
      await sendYouTubeAudioFallback(chatId, url, caption);
      await bot.deleteMessage(chatId, status.message_id).catch(() => {});
      return;
    }

    let mediaUrl = null;
    let title = label;
    let firstError = null;
    try {
      const { data } = await axios.get(AIO_API, { params: { url }, timeout: 60000 });
      mediaUrl = extractMedia(data);
      title = data?.title || data?.data?.title || label;
    } catch (apiError) {
      firstError = apiError;
      console.error("aio download err:", apiError.message);
    }

    const caption = `✅ <b>${esc(label)} Downloaded</b>\n\n🎬 ${esc(cleanTitle(title, label))}${FOOTER}`;
    const isAudio = /\.mp3(\?|$)/i.test(mediaUrl) || label.toLowerCase().includes("song");
    if (!mediaUrl && label.toLowerCase().includes("song") && isYouTubeUrl(url)) {
      await sendYouTubeAudioFallback(chatId, url, caption);
    } else if (!mediaUrl) {
      throw new Error(firstError?.message || "Media URL nahi mila API se.");
    } else if (isAudio) await safeSendAudio(chatId, mediaUrl, { caption, title: cleanTitle(title, label), reply_markup: backToMenuKeyboard() });
    else await safeSendVideo(chatId, mediaUrl, { caption, reply_markup: backToMenuKeyboard() });

    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
  } catch (e) {
    console.error("download err:", e.message);
    await safeEditMessageText(`❌ Download fail: ${esc(e.message)}${FOOTER}`, {
      chat_id: chatId,
      message_id: status.message_id,
    });
  }
}

const cmds = [
  { rx: /^\/tt(?:\s+(.+))?/i, label: "TikTok" },
  { rx: /^\/fb(?:\s+(.+))?/i, label: "Facebook" },
  { rx: /^\/ig(?:\s+(.+))?/i, label: "Instagram" },
];
for (const c of cmds) {
  bot.onText(c.rx, (msg, m) => handleDownload(msg, (m[1] || "").trim(), c.label));
}

// ================= /song (name ya link, dono chalte hain) =================
let ytSearch = null;
try {
  ytSearch = require("yt-search");
} catch (e) {
  console.error("⚠️ yt-search missing. Run: npm install");
}

async function resolveSongUrl(input) {
  if (isHttpUrl(input)) return input;
  if (!ytSearch) throw new Error("Search library install nahi hai. npm install chalao.");
  const r = await ytSearch(input);
  const first = r?.videos?.[0];
  if (!first) throw new Error(`"${input}" ka koi result nahi mila.`);
  return first.url;
}

bot.onText(/^\/song(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = (m[1] || "").trim();

  if (!(await isJoined(userId))) return sendJoinPrompt(chatId);
  if (!input) {
    return safeSendMessage(
      chatId,
      `❌ Song ka naam ya YouTube link bhejo.\n\n<code>/song Dil Dil Ye Dil</code>\n<code>/song https://youtu.be/xxxxxxx</code>${FOOTER}`
    );
  }

  let url;
  try {
    url = await resolveSongUrl(input);
  } catch (e) {
    return safeSendMessage(chatId, `❌ ${esc(e.message)}${FOOTER}`);
  }

  return handleDownload(msg, url, "YouTube Song");
});

// ================= /tr TRANSLATOR =================
bot.onText(/^\/tr(?:\s+(\S+)\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);

  const lang = (m[1] || "").toLowerCase();
  const text = (m[2] || "").trim();
  if (!lang || !text) {
    return safeSendMessage(
      chatId,
      `🌐 <b>Translator</b>\n\nFormat: <code>/tr &lt;lang&gt; &lt;text&gt;</code>\n\n💡 Example: <code>/tr ur Hello my dear friend</code>\n\n` +
        `Common codes: ur, en, hi, ar, es, fr, de, ru, zh, tr, ja, ko, pt, it, bn, fa` +
        FOOTER
    );
  }

  const status = await safeSendMessage(chatId, `🔎 Translating to <b>${esc(lang)}</b>...`);
  try {
    const { data } = await axios.get("https://translate.googleapis.com/translate_a/single", {
      params: { client: "gtx", sl: "auto", tl: lang, dt: "t", q: text },
      timeout: 20000,
    });
    const translated = (data?.[0] || []).map((p) => p[0]).filter(Boolean).join("");
    const src = data?.[2] || "auto";
    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
    await safeSendMessage(
      chatId,
      `🌐 <b>Translation</b>\n\n🔤 <b>From:</b> <code>${esc(src)}</code>  →  <b>To:</b> <code>${esc(lang)}</code>\n\n📝 <b>Original:</b>\n${esc(text)}\n\n✅ <b>Translated:</b>\n${esc(translated)}` +
        FOOTER
    );
  } catch (e) {
    await safeEditMessageText(`❌ Translate fail: ${esc(e.message)}${FOOTER}`, {
      chat_id: chatId,
      message_id: status.message_id,
    });
  }
});

// ================= SIM INFO =================
const SIM_HIDDEN_KEYS = ["developer", "telegram", "channel", "success", "count", "records", "status", "credit", "owner"];

function formatObj(o) {
  return Object.entries(o)
    .filter(([k]) => !SIM_HIDDEN_KEYS.includes(k.toLowerCase()))
    .map(([k, v]) => `• <b>${esc(k)}:</b> <code>${esc(v)}</code>`)
    .join("\n");
}

function extractSimRecords(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.records)) return data.records;
  if (Array.isArray(data?.result)) return data.result;
  if (data && typeof data === "object") return [data];
  return [];
}

bot.onText(/^\/sim(?:\s+(.+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (!(await isJoined(userId))) return sendJoinPrompt(chatId);

  const num = (m[1] || "").replace(/\D/g, "");
  if (!num || num.length < 10) {
    return safeSendMessage(chatId, `❌ Sahi number bhejo\n\n<code>/sim 03XXXXXXXXX</code>${FOOTER}`);
  }

  if (!SIM_API_URL) {
    return safeSendMessage(
      chatId,
      `⚠️ SIM API configure nahi hai.\n<code>.env</code> me <b>SIM_API_URL</b> daalo (use {number} placeholder).${FOOTER}`
    );
  }

  const status = await bot.sendMessage(chatId, `🔎 SIM info fetch ho rahi hai...`);
  try {
    const url = SIM_API_URL.includes("{number}")
      ? SIM_API_URL.replace("{number}", num)
      : SIM_API_URL + encodeURIComponent(num);
    const { data } = await axios.get(url, { timeout: 30000 });

    const records = extractSimRecords(data);
    let text = "";
    if (!records.length) {
      text = "❌ Koi record nahi mila.";
    } else if (records.length === 1) {
      text = formatObj(records[0]);
    } else {
      records.forEach((r, i) => (text += `\n<b>Record ${i + 1}:</b>\n${formatObj(r)}\n`));
    }

    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
    await safeSendMessage(chatId, `📱 <b>SIM Info — ${esc(num)}</b>\n${text}${FOOTER}`, {
      reply_markup: backToMenuKeyboard(),
    });
  } catch (e) {
    await safeEditMessageText(`❌ SIM fetch fail: ${esc(e.message)}${FOOTER}`, {
      chat_id: chatId,
      message_id: status.message_id,
    });
  }
});

// ================= FILE → DIRECT URL (/url) =================
async function handleToUrl(msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (!(await isJoined(userId))) return sendJoinPrompt(chatId);

  const source =
    msg.reply_to_message?.photo ||
    msg.reply_to_message?.document ||
    msg.reply_to_message?.video ||
    msg.reply_to_message?.audio
      ? msg.reply_to_message
      : msg;

  const media =
    (source.photo && source.photo[source.photo.length - 1]) ||
    source.document ||
    source.video ||
    source.audio;

  if (!media) {
    return safeSendMessage(
      chatId,
      `❌ Photo, video ya audio bhejo, caption me <code>/url</code> likh kar. Ya kisi media par reply karke <code>/url</code> bhejo.${FOOTER}`
    );
  }

  const status = await safeSendMessage(chatId, `⏳ Link ban raha hai...`);
  try {
    const fileLink = await bot.getFileLink(media.file_id);
    const { data: fileBuffer } = await axios.get(fileLink, {
      responseType: "arraybuffer",
      timeout: 60000,
    });

    const ext = path.extname(fileLink) || ".jpg";
    const buffer = Buffer.from(fileBuffer);
    const browserHeaders = {
      "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
      accept: "*/*",
    };

    let url = null;
    let lastError = null;

    // Multiple upload services — pehla jo kaam kare wo use hoga
    const uploaders = [
      {
        name: "catbox",
        run: async () => {
          const f = new FormData();
          f.append("reqtype", "fileupload");
          f.append("fileToUpload", buffer, { filename: `file${ext}` });
          const r = await axios.post("https://catbox.moe/user/api.php", f, {
            headers: { ...f.getHeaders(), ...browserHeaders }, timeout: 60000,
          });
          return String(r.data).trim();
        },
      },
      {
        name: "tmpfiles",
        run: async () => {
          const f = new FormData();
          f.append("file", buffer, { filename: `file${ext}` });
          const r = await axios.post("https://tmpfiles.org/api/v1/upload", f, {
            headers: { ...f.getHeaders(), ...browserHeaders }, timeout: 60000,
          });
          const link = r.data?.data?.url || "";
          // tmpfiles returns a view page URL — convert to direct download
          return link.replace("tmpfiles.org/", "tmpfiles.org/dl/").trim();
        },
      },
      {
        name: "uguu",
        run: async () => {
          const f = new FormData();
          f.append("files[]", buffer, { filename: `file${ext}` });
          const r = await axios.post("https://uguu.se/upload.php", f, {
            headers: { ...f.getHeaders(), ...browserHeaders }, timeout: 60000,
          });
          return (r.data?.files?.[0]?.url || "").trim();
        },
      },
      {
        name: "fileio",
        run: async () => {
          const f = new FormData();
          f.append("file", buffer, { filename: `file${ext}` });
          const r = await axios.post("https://file.io/?expires=1d", f, {
            headers: { ...f.getHeaders(), ...browserHeaders }, timeout: 60000,
          });
          return (r.data?.link || "").trim();
        },
      },
      {
        name: "0x0",
        run: async () => {
          const f = new FormData();
          f.append("file", buffer, { filename: `file${ext}` });
          const r = await axios.post("https://0x0.st", f, {
            headers: { ...f.getHeaders(), ...browserHeaders }, timeout: 60000,
          });
          return String(r.data).trim();
        },
      },
    ];

    for (const up of uploaders) {
      try {
        const link = await up.run();
        if (isHttpUrl(link)) { url = link; break; }
        lastError = new Error(`${up.name}: ${link || "empty"}`);
      } catch (e) {
        lastError = e;
        console.error(`${up.name} err:`, e.response?.status || "", e.message);
      }
    }

    if (!url) throw lastError || new Error("Sab upload services fail. Thodi der baad try karo.");

    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
    await safeSendMessage(chatId, `✅ <b>Direct URL:</b>\n<code>${esc(url)}</code>${FOOTER}`, {
      reply_markup: backToMenuKeyboard(),
    });
  } catch (e) {
    console.error("url err:", e.message);
    await safeEditMessageText(`❌ Link banane me fail: ${esc(e.message)}${FOOTER}`, {
      chat_id: chatId,
      message_id: status.message_id,
    });
  }
}

bot.onText(/^\/url\b/i, handleToUrl);

// ================= PHOTO (SS) FORWARD TO OWNER, ya /url =================
bot.on("photo", async (msg) => {
  if (msg.caption && /^\/url\b/i.test(msg.caption.trim())) return handleToUrl(msg);
  try {
    const userId = msg.from.id;
    const chatId = msg.chat.id;
    const order = pendingOrder.get(userId);

    // Agar /order flow se koi pending order nahi hai to ye sirf ek normal photo hai
    // (jaise /url ke liye reply banane wali photo) — owner ko forward mat karo.
    if (!order) return;

    const uname = msg.from.username ? "@" + msg.from.username : "(no username)";
    const fname = [msg.from.first_name, msg.from.last_name].filter(Boolean).join(" ");

    const fileId = msg.photo[msg.photo.length - 1].file_id;

    const caption =
      `🧾 <b>NEW ORDER SS</b>\n\n` +
      `👤 Name: <b>${esc(fname || "Unknown")}</b>\n` +
      `🆔 User ID: <code>${esc(userId)}</code>\n` +
      `🔗 Username: ${esc(uname)}\n\n` +
      `📦 <b>Plan:</b> ${esc(order.plan)}\n💰 <b>Price:</b> ${esc(order.priceText)}\n` +
      (msg.caption ? `\n📝 Note: ${esc(msg.caption)}\n` : "") +
      FOOTER;

    await safeSendPhoto(OWNER_ID, fileId, { caption }).catch((e) => {
      console.error("owner forward fail:", e.message);
    });

    await safeSendMessage(
      chatId,
      `✅ <b>Screenshot receive ho gaya!</b>\n\nOwner ko forward kar diya hai. Owner jaldi contact karega:\n👉 https://t.me/${esc(OWNER_USERNAME)}${FOOTER}`
    );

    pendingOrder.delete(userId);
  } catch (e) {
    console.error("photo handler err:", e.message);
  }
});

// /url support jab photo ke bajaye video/audio/document bheja jaye
bot.on("document", (msg) => {
  if (msg.caption && /^\/url\b/i.test(msg.caption.trim())) return handleToUrl(msg);
});
bot.on("video", (msg) => {
  if (msg.caption && /^\/url\b/i.test(msg.caption.trim())) return handleToUrl(msg);
});
bot.on("audio", (msg) => {
  if (msg.caption && /^\/url\b/i.test(msg.caption.trim())) return handleToUrl(msg);
});

// ================= /autopost (owner-only, scheduled posting) =================
const AUTOPOST_FILE = path.join(__dirname, "autopost.json");
let autopostJob = null;
let autopostConfig = { active: false, intervalMinutes: 0, target: "", message: "" };

function loadAutopostConfig() {
  try {
    if (fs.existsSync(AUTOPOST_FILE)) {
      autopostConfig = JSON.parse(fs.readFileSync(AUTOPOST_FILE, "utf8"));
    }
  } catch (e) {
    console.error("autopost load err:", e.message);
  }
}

function saveAutopostConfig() {
  try {
    fs.writeFileSync(AUTOPOST_FILE, JSON.stringify(autopostConfig, null, 2));
  } catch (e) {
    console.error("autopost save err:", e.message);
  }
}

function stopAutopostJob() {
  if (autopostJob) clearInterval(autopostJob);
  autopostJob = null;
}

// ============ EXTRA BOT TOKENS (multi-bot autopost) ============
const PUSTTOKEN_FILE = path.join(__dirname, "pusttokens.json");
let pustState = { tokens: [], limit: 1 }; // limit = posts per cycle per token

function loadPustTokens() {
  try {
    if (fs.existsSync(PUSTTOKEN_FILE)) {
      pustState = { ...pustState, ...JSON.parse(fs.readFileSync(PUSTTOKEN_FILE, "utf8")) };
    }
  } catch (e) { console.error("pusttoken load err:", e.message); }
}
function savePustTokens() {
  try { fs.writeFileSync(PUSTTOKEN_FILE, JSON.stringify(pustState, null, 2)); }
  catch (e) { console.error("pusttoken save err:", e.message); }
}
loadPustTokens();

async function tgSend(token, chatId, text) {
  const r = await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
    chat_id: chatId, text, parse_mode: "HTML",
  }, { timeout: 30000 });
  return r.data?.result;
}

async function sendAutopostOnce() {
  const results = [];
  // Main bot post
  try {
    const sent = await safeSendMessage(autopostConfig.target, autopostConfig.message);
    results.push({ bot: "main", ok: !!sent });
    try {
      await axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/setMessageReaction`, {
        chat_id: autopostConfig.target, message_id: sent.message_id,
        reaction: [{ type: "emoji", emoji: "🔥" }],
      });
    } catch {}
  } catch (e) { results.push({ bot: "main", ok: false, err: e.message }); }

  // Sub-bots — har token se `limit` baar post
  const limit = Math.max(1, pustState.limit || 1);
  for (const t of pustState.tokens) {
    for (let i = 0; i < limit; i++) {
      try {
        await tgSend(t, autopostConfig.target, autopostConfig.message);
        results.push({ bot: t.slice(0, 8) + "…", ok: true });
      } catch (e) {
        results.push({ bot: t.slice(0, 8) + "…", ok: false, err: e.response?.data?.description || e.message });
      }
      await new Promise((r) => setTimeout(r, 400));
    }
  }
  return results;
}

function startAutopostJob() {
  stopAutopostJob();
  if (!autopostConfig.active) return;
  autopostJob = setInterval(async () => {
    try {
      await sendAutopostOnce();
    } catch (e) {
      console.error("autopost send err:", e.message);
      await safeSendMessage(
        OWNER_ID,
        `⚠️ Autopost fail ho gaya: ${esc(e.message)}\n\nCheck karo bot target (<code>${esc(autopostConfig.target)}</code>) me admin hai ya nahi.${FOOTER}`
      ).catch(() => {});
    }
  }, autopostConfig.intervalMinutes * 60 * 1000);
}

loadAutopostConfig();
startAutopostJob();

// Target ko normalize karo: sirf digits (chat_id) ya "@" wala username chahiye
function normalizeTarget(raw) {
  if (/^-?\d+$/.test(raw)) return raw; // numeric chat id
  return raw.startsWith("@") ? raw : `@${raw}`;
}

bot.onText(/^\/autopost(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);

  if (userId !== String(OWNER_ID)) {
    return safeSendMessage(chatId, `❌ Ye command sirf owner use kar sakta hai.${FOOTER}`);
  }

  const rest = (m[1] || "").trim();

  if (/^off$/i.test(rest)) {
    autopostConfig.active = false;
    saveAutopostConfig();
    stopAutopostJob();
    return safeSendMessage(chatId, `🛑 Autopost band kar diya gaya.${FOOTER}`);
  }

  if (/^status$/i.test(rest)) {
    if (!autopostConfig.active) return safeSendMessage(chatId, `ℹ️ Autopost abhi off hai.${FOOTER}`);
    return safeSendMessage(
      chatId,
      `✅ <b>Autopost ON</b>\n\n⏱ Interval: har ${esc(autopostConfig.intervalMinutes)} minute\n🎯 Target: ${esc(autopostConfig.target)}\n📝 Message:\n${esc(autopostConfig.message)}${FOOTER}`
    );
  }

  const onMatch = rest.match(/^on\s+(\d+)\s+(\S+)\s+([\s\S]+)/i);
  if (!onMatch) {
    return safeSendMessage(
      chatId,
      `📖 <b>Autopost Guide</b>\n\n` +
        `Start: <code>/autopost on &lt;minutes&gt; &lt;@channel ya chat_id&gt; &lt;message&gt;</code>\n` +
        `Example:\n<code>/autopost on 30 @mychannel\nChannel join karo aur latest updates paayein!</code>\n\n` +
        `Stop: <code>/autopost off</code>\n` +
        `Status: <code>/autopost status</code>${FOOTER}`
    );
  }

  const [, minutesStr, rawTarget, message] = onMatch;
  const intervalMinutes = parseInt(minutesStr, 10);
  const target = normalizeTarget(rawTarget);
  if (!intervalMinutes || intervalMinutes < 1) {
    return safeSendMessage(chatId, `❌ Interval kam se kam 1 minute hona chahiye.${FOOTER}`);
  }

  autopostConfig = { active: true, intervalMinutes, target, message };
  saveAutopostConfig();
  startAutopostJob();

  // Turant ek pehla post bhi bhej dete hain, taake confirm ho jaye ke sahi kaam kar raha hai
  try {
    await sendAutopostOnce();
    return safeSendMessage(
      chatId,
      `✅ <b>Autopost ON ho gaya!</b> Pehla post bhi bhej diya gaya hai.\n\n⏱ Har ${esc(intervalMinutes)} minute\n🎯 Target: ${esc(target)}${FOOTER}`
    );
  } catch (e) {
    console.error("autopost first send err:", e.message);
    return safeSendMessage(
      chatId,
      `⚠️ Autopost ON to ho gaya hai, lekin pehla post fail hua:\n<code>${esc(e.message)}</code>\n\n` +
        `Sabse aam wajah: bot <code>${esc(target)}</code> me admin nahi hai, ya target ka naam/ID galat hai.${FOOTER}`
    );
  }
});

// ================= OWNER-ONLY: /stats =================
bot.onText(/^\/stats\b/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  if (userId !== String(OWNER_ID)) return safeSendMessage(chatId, `❌ Ye command sirf owner use kar sakta hai.${FOOTER}`);

  const totalUsers = knownUsers.size;
  const totalBanned = bannedUsers.size;
  const autopostLine = autopostConfig.active
    ? `ON — har ${autopostConfig.intervalMinutes}m → ${autopostConfig.target}`
    : "OFF";

  return safeSendMessage(
    chatId,
    `📊 <b>Bot Stats</b>\n\n` +
      `👥 Total users: <b>${totalUsers}</b>\n` +
      `🚫 Banned: <b>${totalBanned}</b>\n` +
      `📢 Autopost: <b>${esc(autopostLine)}</b>\n` +
      `⏱ Uptime: ${Math.floor(process.uptime() / 60)} minute${FOOTER}`
  );
});

// ================= OWNER-ONLY: /broadcast =================
bot.onText(/^\/broadcast(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  if (userId !== String(OWNER_ID)) return safeSendMessage(chatId, `❌ Ye command sirf owner use kar sakta hai.${FOOTER}`);

  const text = (m[1] || "").trim();
  if (!text) {
    return safeSendMessage(chatId, `📢 Broadcast message likho.\n\n<code>/broadcast Hello everyone!</code>${FOOTER}`);
  }

  const ids = [...knownUsers.keys()];
  const status = await safeSendMessage(chatId, `📤 Broadcast bhej raha hoon 0/${ids.length}...`);
  let sent = 0;
  let failed = 0;

  for (const id of ids) {
    try {
      await safeSendMessage(id, `${text}${FOOTER}`);
      sent++;
    } catch (e) {
      failed++;
    }
    await new Promise((r) => setTimeout(r, 40)); // Telegram rate-limit ke liye chhota gap
  }

  await safeEditMessageText(`✅ Broadcast mukammal!\n\nSent: ${sent}\nFail: ${failed}${FOOTER}`, {
    chat_id: chatId,
    message_id: status.message_id,
  });
});

// ================= OWNER-ONLY: /ban aur /unban =================
bot.onText(/^\/ban(?:\s+(\d+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  if (userId !== String(OWNER_ID)) return safeSendMessage(chatId, `❌ Ye command sirf owner use kar sakta hai.${FOOTER}`);

  const target = (m[1] || "").trim();
  if (!target) return safeSendMessage(chatId, `❌ User ID do.\n\n<code>/ban 123456789</code>${FOOTER}`);

  bannedUsers.add(target);
  saveBannedUsers();
  return safeSendMessage(chatId, `🚫 User <code>${esc(target)}</code> ban kar diya gaya.${FOOTER}`);
});

bot.onText(/^\/unban(?:\s+(\d+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  if (userId !== String(OWNER_ID)) return safeSendMessage(chatId, `❌ Ye command sirf owner use kar sakta hai.${FOOTER}`);

  const target = (m[1] || "").trim();
  if (!target) return safeSendMessage(chatId, `❌ User ID do.\n\n<code>/unban 123456789</code>${FOOTER}`);

  bannedUsers.delete(target);
  saveBannedUsers();
  return safeSendMessage(chatId, `✅ User <code>${esc(target)}</code> unban kar diya gaya.${FOOTER}`);
});

// ================= /pusttoken (owner-only: multi-bot autopost tokens) =================
bot.onText(/^\/pusttoken(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (String(msg.from.id) !== String(OWNER_ID))
    return safeSendMessage(chatId, `❌ Sirf owner ke liye.${FOOTER}`);

  const arg = (m[1] || "").trim();
  const help =
    `🤖 <b>Push Token Manager</b>\n\n` +
    `Extra bot tokens add karo — jab bhi autopost fire hoga, un sab bots se bhi channel me post ho jayega.\n\n` +
    `➕ Add: <code>/pusttoken add &lt;BOT_TOKEN&gt;</code>\n` +
    `➖ Remove: <code>/pusttoken del &lt;index&gt;</code>\n` +
    `📋 List: <code>/pusttoken list</code>\n` +
    `🔢 Limit per bot per cycle: <code>/pusttoken limit &lt;n&gt;</code>\n` +
    `🧹 Clear all: <code>/pusttoken clear</code>${FOOTER}`;

  if (!arg) return safeSendMessage(chatId, help);

  if (/^list$/i.test(arg)) {
    if (!pustState.tokens.length) return safeSendMessage(chatId, `📭 Koi extra token add nahi hai.\n\nLimit: <b>${pustState.limit}</b>${FOOTER}`);
    const list = pustState.tokens.map((t, i) => `${i + 1}. <code>${esc(t.slice(0, 10))}…${esc(t.slice(-4))}</code>`).join("\n");
    return safeSendMessage(chatId, `📋 <b>Extra Bots (${pustState.tokens.length})</b>\n\n${list}\n\n🔢 Limit/cycle: <b>${pustState.limit}</b>${FOOTER}`);
  }

  if (/^clear$/i.test(arg)) {
    pustState.tokens = []; savePustTokens();
    return safeSendMessage(chatId, `🧹 Sab tokens hata diye.${FOOTER}`);
  }

  const limitM = arg.match(/^limit\s+(\d+)/i);
  if (limitM) {
    pustState.limit = Math.max(1, parseInt(limitM[1], 10));
    savePustTokens();
    return safeSendMessage(chatId, `✅ Limit set: <b>${pustState.limit}</b> post per bot per cycle.${FOOTER}`);
  }

  const delM = arg.match(/^del\s+(\d+)/i);
  if (delM) {
    const idx = parseInt(delM[1], 10) - 1;
    if (idx < 0 || idx >= pustState.tokens.length) return safeSendMessage(chatId, `❌ Galat index.${FOOTER}`);
    pustState.tokens.splice(idx, 1); savePustTokens();
    return safeSendMessage(chatId, `✅ Token #${idx + 1} hata diya.${FOOTER}`);
  }

  const addM = arg.match(/^add\s+(\S+)/i);
  if (addM) {
    const token = addM[1].trim();
    if (!/^\d+:[A-Za-z0-9_-]{20,}$/.test(token))
      return safeSendMessage(chatId, `❌ Token ka format galat hai.${FOOTER}`);
    try {
      const r = await axios.get(`https://api.telegram.org/bot${token}/getMe`, { timeout: 15000 });
      const info = r.data?.result;
      if (!info?.username) throw new Error("getMe fail");
      if (pustState.tokens.includes(token)) return safeSendMessage(chatId, `ℹ️ Ye token pehle se add hai.${FOOTER}`);
      pustState.tokens.push(token); savePustTokens();
      return safeSendMessage(chatId, `✅ Add ho gaya: <b>@${esc(info.username)}</b>\nTotal: <b>${pustState.tokens.length}</b>${FOOTER}`);
    } catch (e) {
      return safeSendMessage(chatId, `❌ Token verify fail: ${esc(e.response?.data?.description || e.message)}${FOOTER}`);
    }
  }

  // Direct: /pusttoken <TOKEN>  → verify + (add if new) + turant us token se autopost msg 'limit' baar bhejo
  const rawTokenM = arg.match(/^(\d+:[A-Za-z0-9_-]{20,})$/);
  if (rawTokenM) {
    const token = rawTokenM[1];
    try {
      const r = await axios.get(`https://api.telegram.org/bot${token}/getMe`, { timeout: 15000 });
      const info = r.data?.result;
      if (!info?.username) throw new Error("getMe fail");
      const isNew = !pustState.tokens.includes(token);
      if (isNew) { pustState.tokens.push(token); savePustTokens(); }
      if (!autopostConfig.active || !autopostConfig.target || !autopostConfig.message) {
        return safeSendMessage(chatId,
          `${isNew ? "✅ Add" : "ℹ️ Already"}: <b>@${esc(info.username)}</b>\n\n⚠️ Autopost OFF hai. Pehle <code>/autopost on &lt;min&gt; &lt;target&gt; &lt;msg&gt;</code> chalao.${FOOTER}`);
      }
      const limit = Math.max(1, pustState.limit || 1);
      let ok = 0, fail = 0, lastErr = "";
      for (let i = 0; i < limit; i++) {
        try { await tgSend(token, autopostConfig.target, autopostConfig.message); ok++; }
        catch (e) { fail++; lastErr = e.response?.data?.description || e.message; }
        await new Promise((r) => setTimeout(r, 400));
      }
      return safeSendMessage(chatId,
        `🚀 <b>@${esc(info.username)}</b> se post fire ho gaya!\n\n✅ Success: <b>${ok}</b>   ❌ Fail: <b>${fail}</b>\n🎯 Target: <code>${esc(autopostConfig.target)}</code>` +
        (fail ? `\n\n⚠️ <code>${esc(lastErr)}</code>` : "") +
        (isNew ? `\n\n➕ Token list me add ho gaya (total: ${pustState.tokens.length}).` : "") + FOOTER);
    } catch (e) {
      return safeSendMessage(chatId, `❌ Fail: ${esc(e.response?.data?.description || e.message)}${FOOTER}`);
    }
  }

  return safeSendMessage(chatId, help);
});

// ================= AI CHATBOT (/ai + voice → Urdu) =================
// Groq (free) OpenAI-compatible endpoint recommend hai.
// .env: AI_API_KEY=...  AI_BASE_URL=https://api.groq.com/openai/v1
//        AI_CHAT_MODEL=llama-3.3-70b-versatile   AI_STT_MODEL=whisper-large-v3
const AI_API_KEY = process.env.AI_API_KEY || "";
const AI_BASE_URL = (process.env.AI_BASE_URL || "https://api.groq.com/openai/v1").replace(/\/$/, "");
const AI_CHAT_MODEL = process.env.AI_CHAT_MODEL || "llama-3.3-70b-versatile";
const AI_STT_MODEL = process.env.AI_STT_MODEL || "whisper-large-v3";

const SYSTEM_PROMPT =
  "Tum ek friendly Urdu AI assistant ho jiska naam 'BILAL KING AI' hai. " +
  "Jawab hamesha Roman Urdu / Urdu me do (jab tak user khud kisi aur zuban me na maange). " +
  "Chhote, madadgar, aur clear jawab do. Zaroorat ho to bullet points use karo.";

const aiHistory = new Map(); // userId -> [{role,content}...]

async function aiChat(userId, userText) {
  if (!AI_API_KEY) throw new Error("AI_API_KEY .env me set nahi hai");
  const hist = aiHistory.get(userId) || [];
  const messages = [
    { role: "system", content: SYSTEM_PROMPT },
    ...hist,
    { role: "user", content: userText },
  ];
  const r = await axios.post(
    `${AI_BASE_URL}/chat/completions`,
    { model: AI_CHAT_MODEL, messages, temperature: 0.7 },
    { headers: { Authorization: `Bearer ${AI_API_KEY}` }, timeout: 60000 }
  );
  const reply = r.data?.choices?.[0]?.message?.content?.trim() || "(khali jawab)";
  hist.push({ role: "user", content: userText }, { role: "assistant", content: reply });
  // Sirf akhri 10 turns rakho
  aiHistory.set(userId, hist.slice(-20));
  return reply;
}

bot.onText(/^\/ai(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const q = (m[1] || "").trim();
  if (!q) return safeSendMessage(chatId, `🤖 <b>AI Chat</b>\n\nUse: <code>/ai apna sawal likho</code>\nReset: <code>/aireset</code>${FOOTER}`);
  const status = await safeSendMessage(chatId, `⏳ Soch raha hoon...`);
  try {
    const reply = await aiChat(msg.from.id, q);
    await safeEditMessageText(`🤖 <b>BILAL KING AI</b>\n\n${esc(reply)}${FOOTER}`, {
      chat_id: chatId, message_id: status.message_id,
    });
  } catch (e) {
    await safeEditMessageText(`❌ AI fail: ${esc(e.response?.data?.error?.message || e.message)}${FOOTER}`, {
      chat_id: chatId, message_id: status.message_id,
    });
  }
});

bot.onText(/^\/aireset\b/i, (msg) => {
  aiHistory.delete(msg.from.id);
  safeSendMessage(msg.chat.id, `🧹 AI history clear ho gayi.${FOOTER}`);
});

// ============ VOICE MESSAGE HANDLER — transcribe + Urdu translate + AI reply ============
async function transcribeVoice(fileUrl) {
  if (!AI_API_KEY) throw new Error("AI_API_KEY .env me set nahi hai");
  const { data: buf } = await axios.get(fileUrl, { responseType: "arraybuffer", timeout: 60000 });
  const form = new FormData();
  form.append("file", Buffer.from(buf), { filename: "voice.ogg", contentType: "audio/ogg" });
  form.append("model", AI_STT_MODEL);
  form.append("response_format", "verbose_json");
  const r = await axios.post(`${AI_BASE_URL}/audio/transcriptions`, form, {
    headers: { ...form.getHeaders(), Authorization: `Bearer ${AI_API_KEY}` },
    timeout: 120000, maxBodyLength: Infinity,
  });
  return { text: r.data?.text || "", language: r.data?.language || "" };
}

async function handleVoiceMessage(msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (!(await isJoined(userId))) return sendJoinPrompt(chatId);
  if (!AI_API_KEY) {
    return safeSendMessage(chatId, `⚠️ Voice AI abhi enable nahi hai. Owner ko <code>AI_API_KEY</code> .env me set karna hoga.${FOOTER}`);
  }
  const status = await safeSendMessage(chatId, `🎧 Voice sun raha hoon...`);
  try {
    const media = msg.voice || msg.audio;
    const fileUrl = await bot.getFileLink(media.file_id);
    const { text, language } = await transcribeVoice(fileUrl);
    if (!text.trim()) throw new Error("Voice me kuch samajh nahi aya");

    await safeEditMessageText(`📝 Transcribe ho gaya, ab Urdu me samjha raha hoon...`, {
      chat_id: chatId, message_id: status.message_id,
    });

    const prompt =
      `User ne voice bheja hai. Original transcript (language: ${language || "unknown"}):\n"""${text}"""\n\n` +
      `1) Is baat ka Urdu tarjuma do (Roman Urdu me).\n` +
      `2) Phir madadgar Urdu jawab do.\n` +
      `Format:\n🌐 Urdu Tarjuma: ...\n💬 Jawab: ...`;
    const reply = await aiChat(userId, prompt);

    await safeSendMessage(
      chatId,
      `🎧 <b>Voice → Text</b>\n<code>${esc(text)}</code>\n\n${esc(reply)}${FOOTER}`
    );
    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
  } catch (e) {
    await safeEditMessageText(`❌ Voice AI fail: ${esc(e.response?.data?.error?.message || e.message)}${FOOTER}`, {
      chat_id: chatId, message_id: status.message_id,
    });
  }
}

bot.on("voice", handleVoiceMessage);
bot.on("audio", (msg) => {
  // audio ke sath /url caption ho to woh handler already chalega — warna AI transcribe
  if (msg.caption && /^\/url\b/i.test(msg.caption.trim())) return;
  handleVoiceMessage(msg);
});

// ================= /ckerror & /fixerror & /encrypt =================
let JavaScriptObfuscator = null;
try { JavaScriptObfuscator = require("javascript-obfuscator"); } catch {}
let AdmZip = null;
try { AdmZip = require("adm-zip"); } catch {}

async function extractCodeFromMsg(msg) {
  // Reply to a code/document message, or /cmd <code>, or /cmd inside code block
  const target = msg.reply_to_message || msg;
  // Document
  if (target.document) {
    try {
      const link = await bot.getFileLink(target.document.file_id);
      const { data } = await axios.get(link, { responseType: "arraybuffer", timeout: 60000, maxContentLength: 5 * 1024 * 1024 });
      return { code: Buffer.from(data).toString("utf8"), filename: target.document.file_name || "code.js" };
    } catch (e) { throw new Error("Document read fail: " + e.message); }
  }
  const raw = target.text || target.caption || "";
  const stripped = raw.replace(/^\/(ckerror|fixerror|encrypt)(@\w+)?\s*/i, "");
  const codeBlock = stripped.match(/```(?:\w+)?\n?([\s\S]*?)```/);
  const code = (codeBlock ? codeBlock[1] : stripped).trim();
  return { code, filename: "code.js" };
}

async function aiRaw(prompt) {
  if (!AI_API_KEY) throw new Error("AI_API_KEY .env me set nahi hai");
  const r = await axios.post(
    `${AI_BASE_URL}/chat/completions`,
    { model: AI_CHAT_MODEL, temperature: 0.2, messages: [
      { role: "system", content: "You are a senior Node.js/JavaScript code reviewer. Reply concisely in Roman Urdu + English mix." },
      { role: "user", content: prompt },
    ]},
    { headers: { Authorization: `Bearer ${AI_API_KEY}` }, timeout: 120000 }
  );
  return r.data?.choices?.[0]?.message?.content?.trim() || "";
}

bot.onText(/^\/ckerror\b/i, async (msg) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const status = await safeSendMessage(chatId, `🔎 Code check kar raha hoon...`);
  try {
    const { code } = await extractCodeFromMsg(msg);
    if (!code) throw new Error("Koi code nahi mila. Code paste karo ya code message ko reply karo.");
    const reply = await aiRaw(
      `Neeche di gayi JavaScript/Node.js code me errors, bugs, syntax issues, aur risky patterns list karo. ` +
      `Har issue ke sath line number aur short reason do. Fix mat likho — sirf errors.\n\n\`\`\`js\n${code.slice(0, 12000)}\n\`\`\``
    );
    await safeEditMessageText(`🐞 <b>Error Report</b>\n\n${esc(reply).slice(0, 3800)}${FOOTER}`, {
      chat_id: chatId, message_id: status.message_id,
    });
  } catch (e) {
    await safeEditMessageText(`❌ ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

bot.onText(/^\/fixerror\b/i, async (msg) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const status = await safeSendMessage(chatId, `🛠 Fix kar raha hoon...`);
  try {
    const { code, filename } = await extractCodeFromMsg(msg);
    if (!code) throw new Error("Koi code nahi mila. Code paste karo ya reply karo.");
    const reply = await aiRaw(
      `Fix all bugs/errors in this JavaScript/Node.js code. Return ONLY the corrected full code inside a single \`\`\`js code block. ` +
      `No prose before or after.\n\n\`\`\`js\n${code.slice(0, 12000)}\n\`\`\``
    );
    const m = reply.match(/```(?:js|javascript)?\n?([\s\S]*?)```/);
    const fixed = (m ? m[1] : reply).trim();
    // Send as file if long, else as message
    if (fixed.length > 3500) {
      const tmp = path.join(os.tmpdir(), `fixed-${Date.now()}-${filename.replace(/[^\w.\-]/g, "_")}`);
      fs.writeFileSync(tmp, fixed);
      await bot.sendDocument(chatId, tmp, { caption: `✅ Fixed code${FOOTER}`, parse_mode: "HTML" });
      fs.unlink(tmp, () => {});
      await bot.deleteMessage(chatId, status.message_id).catch(() => {});
    } else {
      await safeEditMessageText(`✅ <b>Fixed</b>\n\n<pre>${esc(fixed)}</pre>${FOOTER}`, {
        chat_id: chatId, message_id: status.message_id,
      });
    }
  } catch (e) {
    await safeEditMessageText(`❌ ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

// /encrypt — user zip (JS/Node project) bheje ya reply kare → sab .js obfuscate karke wapas zip bhejo
function obfuscateJs(src) {
  if (!JavaScriptObfuscator) throw new Error("javascript-obfuscator missing. Run: npm install");
  return JavaScriptObfuscator.obfuscate(src, {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.75,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.3,
    stringArray: true,
    stringArrayEncoding: ["base64"],
    stringArrayThreshold: 0.75,
    identifierNamesGenerator: "hexadecimal",
    selfDefending: false,
    disableConsoleOutput: false,
  }).getObfuscatedCode();
}

bot.onText(/^\/encrypt\b/i, async (msg) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const target = msg.reply_to_message || msg;
  const doc = target.document;

  const status = await safeSendMessage(chatId, `🔐 Encrypt kar raha hoon...`);
  try {
    if (!AdmZip) throw new Error("adm-zip missing. Run: npm install");
    if (!JavaScriptObfuscator) throw new Error("javascript-obfuscator missing. Run: npm install");

    // Case A: single .js file text
    if (!doc) {
      const { code } = await extractCodeFromMsg(msg);
      if (!code) throw new Error("Zip file ya .js code bhejo (ya code message ko reply karke /encrypt).");
      const out = obfuscateJs(code);
      const tmp = path.join(os.tmpdir(), `encrypted-${Date.now()}.js`);
      fs.writeFileSync(tmp, out);
      await bot.sendDocument(chatId, tmp, { caption: `🔐 Encrypted${FOOTER}`, parse_mode: "HTML" });
      fs.unlink(tmp, () => {});
      await bot.deleteMessage(chatId, status.message_id).catch(() => {});
      return;
    }

    const name = (doc.file_name || "").toLowerCase();
    const link = await bot.getFileLink(doc.file_id);
    const { data } = await axios.get(link, { responseType: "arraybuffer", timeout: 120000, maxContentLength: 50 * 1024 * 1024 });
    const buf = Buffer.from(data);

    // Case B: single .js file
    if (name.endsWith(".js")) {
      const out = obfuscateJs(buf.toString("utf8"));
      const tmp = path.join(os.tmpdir(), `encrypted-${Date.now()}-${name.replace(/[^\w.\-]/g, "_")}`);
      fs.writeFileSync(tmp, out);
      await bot.sendDocument(chatId, tmp, { caption: `🔐 Encrypted${FOOTER}`, parse_mode: "HTML" });
      fs.unlink(tmp, () => {});
      await bot.deleteMessage(chatId, status.message_id).catch(() => {});
      return;
    }

    // Case C: zip
    if (!name.endsWith(".zip")) throw new Error("Sirf .zip ya .js support hai.");
    const zip = new AdmZip(buf);
    const outZip = new AdmZip();
    let jsCount = 0, skipCount = 0, keptCount = 0;
    // Files jo kabhi encrypt NA ho — token/config safe rahe
    const PROTECTED_BASENAMES = new Set([
      "config.js", "config.json", "settings.js", "settings.json",
      "package.json", "package-lock.json", "yarn.lock", "bun.lock", "pnpm-lock.yaml",
      ".env", ".env.example", ".env.local",
    ]);
    function isProtectedName(ename) {
      const base = ename.split("/").pop().toLowerCase();
      return PROTECTED_BASENAMES.has(base);
    }
    for (const entry of zip.getEntries()) {
      if (entry.isDirectory) continue;
      const ename = entry.entryName;
      // Skip junk
      if (/(^|\/)node_modules\//i.test(ename) || /(^|\/)\.git\//i.test(ename)) continue;
      const raw = entry.getData();
      if (/\.js$/i.test(ename) && !/\.min\.js$/i.test(ename) && !isProtectedName(ename)) {
        try {
          const obf = obfuscateJs(raw.toString("utf8"));
          outZip.addFile(ename, Buffer.from(obf, "utf8"));
          jsCount++;
        } catch {
          outZip.addFile(ename, raw); skipCount++;
        }
      } else {
        outZip.addFile(ename, raw);
        if (isProtectedName(ename)) keptCount++;
      }
    }
    const outPath = path.join(os.tmpdir(), `encrypted-${Date.now()}-${name.replace(/[^\w.\-]/g, "_")}`);
    outZip.writeZip(outPath);
    await bot.sendDocument(chatId, outPath, {
      caption: `🔐 <b>Encrypted ZIP</b>\n✅ JS obfuscated: <b>${jsCount}</b>${keptCount ? `\n🛡️ Config/Package safe kept: <b>${keptCount}</b>` : ""}${skipCount ? `\n⚠️ Skipped: <b>${skipCount}</b>` : ""}${FOOTER}`,
      parse_mode: "HTML",
    });
    fs.unlink(outPath, () => {});
    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
  } catch (e) {
    await safeEditMessageText(`❌ Encrypt fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

console.log(`🤖 ${BRAND} BOT running...`);

// ================= PRINCE TECH API COMMANDS =================
async function princeFetch(pathAndQuery) {
  const url = princeUrl(pathAndQuery);
  const { data } = await axios.get(url, { timeout: 60000 });
  return data;
}

async function aiFallback(urls) {
  let lastErr = "";
  for (const u of urls) {
    try {
      const { data } = await axios.get(u, { timeout: 45000, headers: { "user-agent": "Mozilla/5.0" } });
      const r = data?.result || data?.data || data;
      const ans = (typeof r === "string" ? r
        : r?.response || r?.answer || r?.text || r?.message || r?.result || r?.output || r?.gemini || r?.content || "").toString();
      if (ans.trim()) return ans;
    } catch (e) { lastErr = e.message; }
  }
  throw new Error(lastErr || "AI providers fail");
}

// ===== Backup AIO downloader providers (used if Prince Tech fails) =====
async function backupDownload(kind, url) {
  // kind: "xnxx" | "fb" | "tt" | "ig" | "yt" | "mediafire"
  const providers = [];
  // 1) siputzx (public, no key)
  const siputzxMap = { xnxx: "xnxx", fb: "facebook", tt: "tiktok", ig: "instagram", yt: "ytmp4", mediafire: "mediafire" };
  if (siputzxMap[kind]) providers.push(`https://api.siputzx.my.id/api/d/${siputzxMap[kind]}?url=${encodeURIComponent(url)}`);
  // 2) DavidCyril (public)
  const davMap = { xnxx: "xnxxdl", fb: "facebook", tt: "tiktok", ig: "instagram", yt: "ytmp4", mediafire: "mediafire" };
  if (davMap[kind]) providers.push(`https://api.davidcyriltech.my.id/download/${davMap[kind]}?url=${encodeURIComponent(url)}`);
  // 3) Vreden
  const vredMap = { fb: "facebook", tt: "tiktok", ig: "instagram", yt: "ytmp4" };
  if (vredMap[kind]) providers.push(`https://api.vreden.my.id/api/${vredMap[kind]}?url=${encodeURIComponent(url)}`);

  let lastErr = "";
  for (const p of providers) {
    try {
      const { data } = await axios.get(p, { timeout: 45000, headers: { "user-agent": "Mozilla/5.0" } });
      const media = pickMediaFromPrince(data);
      if (media) return { media, title: data?.result?.title || data?.data?.title || "" };
    } catch (e) { lastErr = e.message; }
  }
  throw new Error(lastErr || "All backup providers failed");
}

async function tryDownload(princePaths, kind, url) {
  // Try Prince Tech endpoints first, then backup providers
  for (const ep of princePaths) {
    try {
      const data = await princeFetch(ep);
      const media = pickMediaFromPrince(data);
      if (media) return { media, title: data?.result?.title || data?.data?.title || "" };
    } catch {}
  }
  return backupDownload(kind, url);
}

function pickMediaFromPrince(data) {
  const r = data?.result || data?.data || data;
  const cands = [
    r?.download_url, r?.downloadUrl, r?.dl_url, r?.dlUrl, r?.url, r?.link,
    r?.video, r?.audio, r?.image, r?.file, r?.mp3, r?.mp4,
    r?.hd, r?.sd, r?.no_watermark, r?.nowm,
    Array.isArray(r?.medias) ? r.medias[0]?.url : null,
    Array.isArray(r?.links) ? r.links[0]?.url || r.links[0] : null,
  ];
  for (const c of cands) if (typeof c === "string" && /^https?:\/\//i.test(c)) return c;
  // Deep scan
  const seen = new Set();
  function scan(obj) {
    if (!obj || typeof obj !== "object" || seen.has(obj)) return null;
    seen.add(obj);
    for (const v of Object.values(obj)) {
      if (typeof v === "string" && /^https?:\/\/.+\.(mp4|mp3|m4a|jpg|jpeg|png|webp|gif|mov|webm)(\?|$)/i.test(v)) return v;
    }
    for (const v of Object.values(obj)) {
      if (typeof v === "object") { const r2 = scan(v); if (r2) return r2; }
    }
    return null;
  }
  return scan(r);
}

// /temp <email>
// /temp — generate fake temp mail (1secmail) OR check inbox for provided address
const tempMailStore = new Map(); // userId -> email
bot.onText(/^\/temp(?:\s+(.+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (!(await isJoined(userId))) return sendJoinPrompt(chatId);
  const arg = (m[1] || "").trim();
  const status = await safeSendMessage(chatId, `⏳ Temp mail...`);
  try {
    let email = "";
    if (arg && /^[^\s@]+@[^\s@]+$/.test(arg)) {
      email = arg;
    } else {
      // Generate fresh 1secmail address
      try {
        const g = await axios.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1", { timeout: 20000 });
        email = Array.isArray(g.data) ? g.data[0] : "";
      } catch {}
      if (!email) {
        const domains = ["1secmail.com","1secmail.net","1secmail.org","esiix.com","wwjmp.com"];
        const rand = Math.random().toString(36).slice(2, 12);
        email = `${rand}@${domains[Math.floor(Math.random()*domains.length)]}`;
      }
      tempMailStore.set(userId, email);
    }
    // Fetch inbox via 1secmail
    const [login, domain] = email.split("@");
    let items = [];
    try {
      const r = await axios.get(`https://www.1secmail.com/api/v1/?action=getMessages&login=${encodeURIComponent(login)}&domain=${encodeURIComponent(domain)}`, { timeout: 20000 });
      items = Array.isArray(r.data) ? r.data : [];
    } catch {}
    // Fetch full body for latest 5 messages
    const fetched = [];
    for (const it of items.slice(0, 5)) {
      try {
        const rr = await axios.get(`https://www.1secmail.com/api/v1/?action=readMessage&login=${encodeURIComponent(login)}&domain=${encodeURIComponent(domain)}&id=${it.id}`, { timeout: 20000 });
        fetched.push(rr.data);
      } catch { fetched.push(it); }
    }
    let text =
      `📧 <b>Temp Mail Ready</b>\n\n` +
      `📬 Address: <code>${esc(email)}</code>\n` +
      `♻️ Refresh: <code>/temp ${esc(email)}</code>\n` +
      `━━━━━━━━━━━━━━━\n`;
    if (!fetched.length) {
      text += `\n📭 Abhi koi mail nahi aayi. Kuch der baad refresh karo.`;
    } else {
      fetched.forEach((it, i) => {
        const from = it.from || "?";
        const subj = it.subject || "(no subject)";
        const body = (it.textBody || it.body || "").toString().replace(/<[^>]*>/g, "").slice(0, 400);
        text += `\n<b>#${i + 1}</b>\n👤 <b>From:</b> ${esc(from)}\n📌 <b>Subject:</b> ${esc(subj)}\n\n${esc(body)}\n━━━━━━━━━━━━━━━\n`;
      });
    }
    await safeEditMessageText(text.slice(0, 3800) + FOOTER, {
      chat_id: chatId, message_id: status.message_id, reply_markup: backToMenuKeyboard(),
    });
  } catch (e) {
    await safeEditMessageText(`❌ Temp mail fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

// /bilal-logo <text>
bot.onText(/^\/bilal[-_ ]?logo(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const text = (m[1] || "").trim();
  if (!text) return safeSendMessage(chatId, `🎨 <b>Logo Maker</b>\n\n<code>/bilal-logo Your Name</code>${FOOTER}`);
  const status = await safeSendMessage(chatId, `🎨 Logo bana raha hoon...`);
  try {
    const data = await princeFetch(`/ephoto360/glossysilver?text=${encodeURIComponent(text)}`);
    const img = pickMediaFromPrince(data) || data?.result?.image || data?.result?.url;
    if (!img) throw new Error("Logo image nahi mili.");
    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
    await safeSendPhoto(chatId, img, { caption: `🎨 <b>${esc(text)}</b> — Glossy Silver Logo${FOOTER}`, reply_markup: backToMenuKeyboard() });
  } catch (e) {
    await safeEditMessageText(`❌ Logo fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

// /mediafire <url>
bot.onText(/^\/mediafire(?:\s+(.+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const url = (m[1] || "").trim();
  if (!/^https?:\/\//i.test(url)) return safeSendMessage(chatId, `📥 <code>/mediafire &lt;link&gt;</code>${FOOTER}`);
  const status = await safeSendMessage(chatId, `⏳ Mediafire link nikal raha hoon...`);
  try {
    const { media: dl, title: name } = await tryDownload(
      [`/download/mediafire?url=${encodeURIComponent(url)}`],
      "mediafire", url
    );
    if (!dl) throw new Error("Download link nahi mila.");
    await safeEditMessageText(
      `✅ <b>Mediafire Ready</b>\n\n📄 <b>${esc(name || "file")}</b>\n\n🔗 <a href="${esc(dl)}">Direct Download</a>${FOOTER}`,
      { chat_id: chatId, message_id: status.message_id, reply_markup: backToMenuKeyboard(), disable_web_page_preview: false }
    );
  } catch (e) {
    await safeEditMessageText(`❌ Mediafire fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

// Override /fb — use Prince Tech API
bot.removeTextListener(/^\/fb(?:\s+(.+))?/i);
bot.onText(/^\/fb(?:\s+(.+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const url = (m[1] || "").trim();
  if (!/^https?:\/\//i.test(url)) return safeSendMessage(chatId, `🔵 <code>/fb &lt;facebook link&gt;</code>${FOOTER}`);
  const status = await safeSendMessage(chatId, `⏳ Facebook video download...`);
  try {
    const { media } = await tryDownload(
      [`/download/facebook?url=${encodeURIComponent(url)}`, `/download/fbdl?url=${encodeURIComponent(url)}`],
      "fb", url
    );
    if (!media) throw new Error("Video link nahi mila.");
    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
    await safeSendVideo(chatId, media, { caption: `✅ <b>Facebook Downloaded</b>${FOOTER}`, reply_markup: backToMenuKeyboard() });
  } catch (e) {
    await safeEditMessageText(`❌ FB fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

// Override /tt — use Prince Tech API
bot.removeTextListener(/^\/tt(?:\s+(.+))?/i);
bot.onText(/^\/tt(?:\s+(.+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const url = (m[1] || "").trim();
  if (!/^https?:\/\//i.test(url)) return safeSendMessage(chatId, `🔴 <code>/tt &lt;tiktok link&gt;</code>${FOOTER}`);
  const status = await safeSendMessage(chatId, `⏳ TikTok download...`);
  try {
    const { media } = await tryDownload(
      [`/download/tiktok?url=${encodeURIComponent(url)}`, `/download/ttdl?url=${encodeURIComponent(url)}`],
      "tt", url
    );
    if (!media) throw new Error("Video link nahi mila.");
    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
    await safeSendVideo(chatId, media, { caption: `✅ <b>TikTok Downloaded</b> (no watermark)${FOOTER}`, reply_markup: backToMenuKeyboard() });
  } catch (e) {
    await safeEditMessageText(`❌ TT fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

// /text <text> — Text-to-Speech (voice message)
bot.onText(/^\/text(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const text = (m[1] || "").trim();
  if (!text) return safeSendMessage(chatId, `🗣️ <b>Text to Voice</b>\n\n<code>/text Hello bhai kaise ho</code>${FOOTER}`);
  const status = await safeSendMessage(chatId, `🎙️ Voice bana raha hoon...`);
  try {
    // Primary: StreamElements (Brian, English & mixed OK)
    const providers = [
      { url: `https://api.streamelements.com/kappa/v2/speech?voice=Brian&text=${encodeURIComponent(text)}`, ext: "mp3" },
      { url: `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&q=${encodeURIComponent(text.slice(0, 190))}`, ext: "mp3" },
    ];
    let filePath = null, lastErr = "";
    for (const p of providers) {
      try {
        filePath = await downloadToTempFile(p.url, p.ext);
        if (filePath && fs.statSync(filePath).size > 500) break;
        filePath = null;
      } catch (er) { lastErr = er.message; }
    }
    if (!filePath) throw new Error(lastErr || "TTS provider fail");
    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
    await bot.sendVoice(chatId, filePath, {
      caption: `🗣️ <b>Text → Voice</b>\n\n<i>${esc(text).slice(0, 300)}</i>${FOOTER}`,
      parse_mode: "HTML",
      reply_markup: backToMenuKeyboard(),
    }).catch(async () => {
      await bot.sendAudio(chatId, filePath, {
        caption: `🗣️ <b>Text → Voice</b>${FOOTER}`, parse_mode: "HTML",
        title: "TTS", performer: BRAND, reply_markup: backToMenuKeyboard(),
      });
    });
    fs.unlink(filePath, () => {});
  } catch (e) {
    await safeEditMessageText(`❌ TTS fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

// /bilalg — Gemini AI
bot.onText(/^\/bilalg(?!p)(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const q = (m[1] || "").trim();
  if (!q) return safeSendMessage(chatId, `🤖 <code>/bilalg apna sawal likho</code>${FOOTER}`);
  const status = await safeSendMessage(chatId, `🧠 Gemini soch raha hai...`);
  try {
    const answer = await aiFallback([
      princeUrl(`/ai/geminiai?q=${encodeURIComponent(q)}`),
      `https://api.siputzx.my.id/api/ai/gemini-pro?content=${encodeURIComponent(q)}`,
      `https://api.davidcyriltech.my.id/ai/gemini?text=${encodeURIComponent(q)}`,
      `https://api.dreaded.site/api/gemini2?text=${encodeURIComponent(q)}`,
    ]);
    if (!answer.trim()) throw new Error("Reply nahi mila.");
    await safeEditMessageText(`🤖 <b>BILAL Gemini</b>\n\n${esc(answer).slice(0, 3800)}${FOOTER}`, {
      chat_id: chatId, message_id: status.message_id, reply_markup: backToMenuKeyboard(),
    });
  } catch (e) {
    await safeEditMessageText(`❌ Gemini fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

// /bilalgp — ChatGPT
bot.onText(/^\/bilalgp(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const q = (m[1] || "").trim();
  if (!q) return safeSendMessage(chatId, `💬 <code>/bilalgp apna sawal likho</code>${FOOTER}`);
  const status = await safeSendMessage(chatId, `💬 ChatGPT soch raha hai...`);
  try {
    const answer = await aiFallback([
      princeUrl(`/ai/gpt?q=${encodeURIComponent(q)}`),
      `https://api.siputzx.my.id/api/ai/gpt3?prompt=You are helpful&content=${encodeURIComponent(q)}`,
      `https://api.davidcyriltech.my.id/ai/gpt4?text=${encodeURIComponent(q)}`,
      `https://api.dreaded.site/api/chatgpt?text=${encodeURIComponent(q)}`,
    ]);
    if (!answer.trim()) throw new Error("Reply nahi mila.");
    await safeEditMessageText(`💬 <b>BILAL ChatGPT</b>\n\n${esc(answer).slice(0, 3800)}${FOOTER}`, {
      chat_id: chatId, message_id: status.message_id, reply_markup: backToMenuKeyboard(),
    });
  } catch (e) {
    await safeEditMessageText(`❌ GPT fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

// /xnxx <url>
bot.onText(/^\/xnxx(?:\s+(.+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const url = (m[1] || "").trim();
  if (!/^https?:\/\//i.test(url)) return safeSendMessage(chatId, `🔞 <code>/xnxx &lt;link&gt;</code> (18+ only)${FOOTER}`);
  const status = await safeSendMessage(chatId, `⏳ Download ho raha hai...`);
  try {
    const { media } = await tryDownload(
      [
        `/download/xnxxdl?url=${encodeURIComponent(url)}`,
        `/download/xnxx?url=${encodeURIComponent(url)}`,
        `/download/xvideodl?url=${encodeURIComponent(url)}`,
      ],
      "xnxx", url
    );
    if (!media) throw new Error("Video link nahi mila.");
    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
    await safeSendVideo(chatId, media, { caption: `✅ Downloaded (18+)${FOOTER}`, reply_markup: backToMenuKeyboard() });
  } catch (e) {
    await safeEditMessageText(`❌ Fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

// /play — YouTube MP3 via Prince Tech (song naam ya link). /song purani logic waise hi rahegi.
bot.onText(/^\/play(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const input = (m[1] || "").trim();
  if (!input) return safeSendMessage(chatId, `▶️ <code>/play song name ya youtube link</code>${FOOTER}`);
  const status = await safeSendMessage(chatId, `⏳ Play kar raha hoon...`);
  try {
    let url = input;
    if (!isHttpUrl(url)) {
      if (!ytSearch) throw new Error("yt-search missing, npm install chalao.");
      const r = await ytSearch(input);
      const first = r?.videos?.[0];
      if (!first) throw new Error(`"${input}" ka result nahi mila.`);
      url = first.url;
    }
    const data = await princeFetch(`/download/yta?url=${encodeURIComponent(url)}`);
    const r = data?.result || data?.data || data;
    const title = r?.title || "YouTube Audio";
    const media = pickMediaFromPrince(data);
    if (!media) throw new Error("Audio link nahi mila.");
    await bot.deleteMessage(chatId, status.message_id).catch(() => {});
    await safeSendAudio(chatId, media, {
      caption: `▶️ <b>Playing</b>\n\n🎵 ${esc(cleanTitle(title))}${FOOTER}`,
      title: cleanTitle(title, "YouTube Audio"),
      performer: BRAND,
      reply_markup: backToMenuKeyboard(),
    });
  } catch (e) {
    await safeEditMessageText(`❌ Play fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});

// ================= /video (name ya link) =================
bot.onText(/^\/video(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const input = (m[1] || "").trim();
  if (!(await isJoined(userId))) return sendJoinPrompt(chatId);
  if (!input) {
    return safeSendMessage(
      chatId,
      `❌ Video ka naam ya YouTube link bhejo.\n\n<code>/video kaka new song</code>\n<code>/video https://youtu.be/xxxxxxx</code>${FOOTER}`
    );
  }
  let url = input;
  if (!isHttpUrl(url)) {
    try {
      if (!ytSearch) throw new Error("yt-search missing, npm install chalao.");
      const r = await ytSearch(input);
      const first = r?.videos?.[0];
      if (!first) throw new Error(`"${input}" ka result nahi mila.`);
      url = first.url;
    } catch (e) {
      return safeSendMessage(chatId, `❌ ${esc(e.message)}${FOOTER}`);
    }
  }
  return handleDownload(msg, url, "YouTube Video");
});

// ================= /id — user apni Telegram ID leta hai =================
bot.onText(/^\/id\b/i, async (msg) => {
  const chatId = msg.chat.id;
  const u = msg.from;
  const rep = msg.reply_to_message?.from;
  let text =
    `🆔 <b>Your Telegram Info</b>\n\n` +
    `👤 Name: <b>${esc(u.first_name || "")} ${esc(u.last_name || "")}</b>\n` +
    `🔗 Username: <code>@${esc(u.username || "none")}</code>\n` +
    `🆔 User ID: <code>${u.id}</code>\n` +
    `💬 Chat ID: <code>${chatId}</code>`;
  if (rep) {
    text +=
      `\n\n👥 <b>Replied User</b>\n` +
      `👤 Name: <b>${esc(rep.first_name || "")}</b>\n` +
      `🔗 Username: <code>@${esc(rep.username || "none")}</code>\n` +
      `🆔 User ID: <code>${rep.id}</code>`;
  }
  return safeSendMessage(chatId, text + FOOTER, { reply_markup: backToMenuKeyboard() });
});

// ================= /xsearch <keyword> — 15-20 XNXX result links =================
bot.onText(/^\/xsearch(?:\s+([\s\S]+))?/i, async (msg, m) => {
  const chatId = msg.chat.id;
  if (!(await isJoined(msg.from.id))) return sendJoinPrompt(chatId);
  const q = (m[1] || "").trim();
  if (!q) return safeSendMessage(chatId, `🔞 <b>XNXX Search</b> (18+)\n\n<code>/xsearch keyword</code>${FOOTER}`);
  const status = await safeSendMessage(chatId, `🔎 Search ho raha hai...`);
  try {
    // Try Prince Tech search endpoints in order, then fallback to scraping.
    const endpoints = [
      `/search/xnxxsearch?text=${encodeURIComponent(q)}`,
      `/search/xnxx?text=${encodeURIComponent(q)}`,
      `/search/xnxxsearch?q=${encodeURIComponent(q)}`,
      `/search/xnxx?q=${encodeURIComponent(q)}`,
    ];
    let results = [];
    for (const ep of endpoints) {
      try {
        const data = await princeFetch(ep);
        const r = data?.result || data?.data || data?.results || data;
        const list = Array.isArray(r) ? r : (Array.isArray(r?.results) ? r.results : (Array.isArray(r?.videos) ? r.videos : []));
        if (list.length) { results = list; break; }
      } catch {}
    }
    // Fallback: scrape xnxx.com search page
    if (!results.length) {
      try {
        const html = (await axios.get(`https://www.xnxx.com/search/${encodeURIComponent(q)}`, {
          timeout: 30000,
          headers: { "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36" },
        })).data;
        const seen = new Set();
        const re = /href="(\/video-[a-z0-9]+\/[^"]+)"[^>]*title="([^"]+)"/gi;
        let mm;
        while ((mm = re.exec(html)) && results.length < 20) {
          const link = "https://www.xnxx.com" + mm[1];
          if (seen.has(link)) continue;
          seen.add(link);
          results.push({ title: mm[2], url: link });
        }
      } catch (e) { console.error("xnxx scrape err:", e.message); }
    }
    if (!results.length) throw new Error("Koi result nahi mila.");
    const items = results.slice(0, 20);
    let text = `🔞 <b>Search:</b> <code>${esc(q)}</code>\n<b>Total:</b> ${items.length}\n\n`;
    items.forEach((it, i) => {
      const title = esc((it.title || it.name || "Video").toString()).slice(0, 90);
      const link = it.url || it.link || it.video_url || "";
      text += `<b>${i + 1}.</b> ${title}\n🔗 <code>${esc(link)}</code>\n\n`;
    });
    text += `▶️ Download karne ke liye: <code>/xnxx &lt;link&gt;</code>`;
    await safeEditMessageText(text.slice(0, 3900) + FOOTER, {
      chat_id: chatId, message_id: status.message_id, reply_markup: backToMenuKeyboard(), disable_web_page_preview: true,
    });
  } catch (e) {
    await safeEditMessageText(`❌ Search fail: ${esc(e.message)}${FOOTER}`, { chat_id: chatId, message_id: status.message_id });
  }
});
