# 👑 BILAL KING BOT

Node.js Telegram bot with:
- ✅ Force Join system (user ko pehle channel join karna hoga)
- 🎨 Colorful button menu with photo & caption
- ⬇️ AIO Downloader (TikTok, Facebook, Instagram, YouTube Song & Video)
- 🎧 YouTube audio strong fallback: AIO fail ho to `@vreden/youtube_scraper` MP3 link + local-file send + direct ytdl stream try hota hai
- 📱 Pakistan SIM Info lookup (apni API URL `.env` me daalo)
- 🌐 `/tr` translator command
- 🛒 Auto order menu + payment screenshot owner DM forward
- 🗑️ Auto delete + new menu after every download
- ✨ Footer: `Powered by 𝗕𝗜𝗟𝗔𝗟 𝐊𝐈𝐍𝐆`

## Setup

```bash
npm install
cp .env.example .env
# .env file me BOT_TOKEN, FORCE_JOIN_CHANNEL, SIM_API_URL daalo
npm start
```

> Agar Pterodactyl me purana bot upload kiya hua hai to naya ZIP upload karne ke baad **npm install** zaroor chalao, warna YouTube song ka new fallback install nahi hoga.

## YouTube Song Fix
Screenshot wala error `Sign in to confirm you’re not a bot` direct YouTube/ytdl block ki wajah se tha. Ab `/song` me ye order hai:
1. AIO API try
2. `@vreden/youtube_scraper` se ready MP3 URL
3. Telegram URL se na bhej paye to pehle MP3 temp file me download karke upload
4. Last fallback direct ytdl stream

Is update ke baad **npm install** + **restart** lazmi hai.

## Official Button Style
Menu buttons ko TALHA-style wide colorful layout me update kar diya: Set Profile Photo, Owner/Channel, NEXT divider, SIM Details, Video Downloader, Group/Developer, Auto Order.

## Commands
- `/start` — Menu open karo
- `/tt <url>` — TikTok download
- `/fb <url>` — Facebook download
- `/ig <url>` — Instagram download
- `/song <naam ya url>` — YouTube MP3 (naam se bhi chalega, `/song Dil Dil Ye Dil`)
- `/video <url>` — YouTube MP4
- `/sim <number>` — SIM info (03XXXXXXXXX)
- `/tr <lang> <text>` — Translator, example: `/tr ur Hello friend`
- `/order` — Auto order menu
- `/url` — Photo/video/audio ka direct download URL (caption me `/url` likh kar bhejo, ya media par reply kar ke)
- `/autopost` — **Owner-only.** Scheduled posting kisi channel/group me.
  - `/autopost on <minutes> <@channel ya chat_id> <message>` — start
  - `/autopost off` — stop
  - `/autopost status` — current config dekho
  - Bot us target channel/group me admin (post permission ke sath) hona chahiye.
  - Har autopost ke baad bot khud apni post par ek genuine 🔥 reaction bhi laga deta hai.
- `/stats` — **Owner-only.** Total users, banned count, autopost status.
- `/broadcast <message>` — **Owner-only.** Sab registered users (jinhone kabhi /start kiya ho) ko message bhejta hai.
- `/ban <user_id>` / `/unban <user_id>` — **Owner-only.** Kisi user ko bot use karne se rok do / wapas allow karo.

## Crash Fix
Order buttons par bot off hone ki wajah Telegram Markdown parse error thi (`_` / special characters). Ab bot HTML-safe messages use karta hai aur username/caption/plan text escape hota hai, isliye button click se bot offline nahi hoga.

## Menu Photo
`assets/menu.jpg` replace kar sakte ho apni image se.

---
**Powered by 𝗕𝗜𝗟𝗔𝗟 𝐊𝐈𝐍𝐆**
